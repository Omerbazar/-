# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

### نظام إدارة التأمين الصحي (insurance-app)
- **Type**: Expo mobile app
- **Path**: `artifacts/insurance-app/`
- **Preview**: `/` (root)
- **Framework**: Expo Router (file-based routing)
- **State**: AsyncStorage (no backend required for first build)
- **Language**: Arabic (RTL) interface

#### Features:
- Dashboard with financial stats, quick actions, recent invoices
- Subscribers management (CRUD, exceptional rates, status toggle)
- Invoice creation with automatic coinsurance calculation:
  - Selects subscriber by card code
  - Auto-fetches employer, insurance company, coinsurance rates
  - Selects service department → pulls discount rate (company × department)
  - Calculates: net = total - coinsurance - discount
  - Ceiling enforcement with exception override flow
- Invoice detail with payment recording, cancellation
- Employers management with insurance sections and coinsurance rates
- Insurance companies management with per-department discount tables
- Reports dashboard (financial summary, by company/employer/department)
- Settings (entity info, departments management)

#### Data Model (AsyncStorage):
- `entity`: Main facility info + departments
- `insuranceCompanies`: Companies with per-department discount grids
- `employers`: Companies with insurance sections + coinsurance rates
- `subscribers`: Clients linked to employer section, with exceptional rates
- `invoices`: Full invoice records with payments

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/insurance-app run dev` — run mobile app

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
