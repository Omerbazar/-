const colors = {
  light: {
    text: "#0f172a",
    tint: "#0d9488",

    background: "#f0fafa",
    foreground: "#0f172a",

    card: "#ffffff",
    cardForeground: "#0f172a",

    primary: "#0d9488",
    primaryForeground: "#ffffff",

    secondary: "#e6f7f5",
    secondaryForeground: "#0f5c56",

    muted: "#f1f5f9",
    mutedForeground: "#64748b",

    accent: "#14b8a6",
    accentForeground: "#ffffff",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    success: "#22c55e",
    successForeground: "#ffffff",

    warning: "#f59e0b",
    warningForeground: "#ffffff",

    border: "#e2e8f0",
    input: "#e2e8f0",

    surface: "#ffffff",
    surfaceSecondary: "#f8fafc",
  },
  radius: 12,
};

export default colors;
