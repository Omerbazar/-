export const CURRENCIES = [
  { code: "YER", label: "الريال اليمني" },
  { code: "SAR", label: "الريال السعودي" },
  { code: "USD", label: "الدولار الأمريكي" },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]["code"];

export function isCurrencyCode(value: unknown): value is CurrencyCode {
  return CURRENCIES.some((currency) => currency.code === value);
}
