import type { CurrencyCode } from "@/constants/currencies";
import type { Invoice, PeriodicReport } from "@/context/AppContext";

export function invoiceCurrency(invoice: Pick<Invoice, "currency">): CurrencyCode {
  // Invoices created before currency was stored were entered in SAR in the old UI.
  return invoice.currency ?? "SAR";
}

export function currencyMark(currency: CurrencyCode): string {
  switch (currency) {
    case "YER":
      return "ر.ي";
    case "SAR":
      return "ر.س";
    case "USD":
      return "دولار";
  }
}

export function formatMoney(amount: number, currency: CurrencyCode): string {
  return `${amount.toLocaleString("ar-SA", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })} ${currencyMark(currency)}`;
}

export function reportFinancials(
  report: PeriodicReport,
  invoices: Invoice[]
) {
  const byId = new Map(invoices.map((invoice) => [invoice.id, invoice]));
  const directPaid = report.invoiceIds.reduce(
    (sum, id) => sum + (byId.get(id)?.paidAmount ?? 0),
    0
  );
  const reportPaid = report.settlements.reduce(
    (sum, settlement) => sum + settlement.amount,
    0
  );
  const rejected = report.rejections.reduce(
    (sum, item) => sum + item.amount,
    0
  );
  const paid = Math.min(report.totalAmount, directPaid + reportPaid);
  const outstanding = Math.max(0, report.totalAmount - paid - rejected);
  return { total: report.totalAmount, paid, rejected, outstanding };
}

