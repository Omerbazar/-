import type { CurrencyCode } from "@/constants/currencies";

export interface Department {
  id: string;
  name: string;
  phone: string;
  active?: boolean;
}

export interface MainEntity {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  baseCurrency: CurrencyCode | null;
  departments: Department[];
}
