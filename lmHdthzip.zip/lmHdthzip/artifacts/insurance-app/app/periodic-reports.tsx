import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { Share } from "react-native";
import React, { useMemo, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { useApp, generateId, PeriodicReport } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatMoney, invoiceCurrency } from "@/utils/accounting";

function todayKey() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function initialStart(cadence: "monthly" | "weekly" | "custom", days: number) {
  const date = new Date();
  if (cadence === "monthly") date.setDate(1);
  else if (cadence === "weekly") date.setDate(date.getDate() - 6);
  else date.setDate(date.getDate() - Math.max(1, days) + 1);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

type InvoiceGroup = {
  key: string;
  companyId: string;
  companyName: string;
  departmentId: string | null;
  departmentName: string | null;
  currency: ReturnType<typeof invoiceCurrency>;
  invoices: ReturnType<typeof useApp>["invoices"];
};

export default function PeriodicReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    invoices,
    reports,
    insuranceCompanies,
    entity,
    reportSettings,
    closeReports,
  } = useApp();
  const [dateFrom, setDateFrom] = useState(() =>
    initialStart(reportSettings.cadence, reportSettings.customCycleDays)
  );
  const [dateTo, setDateTo] = useState(todayKey);
  const [confirmClose, setConfirmClose] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const closedInvoiceIds = useMemo(
    () => new Set(reports.flatMap((report) => report.invoiceIds)),
    [reports]
  );
  const grouped = useMemo<InvoiceGroup[]>(() => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateFrom) || !/^\d{4}-\d{2}-\d{2}$/.test(dateTo) || dateFrom > dateTo) return [];
    const eligible = invoices
      .filter(
        (invoice) =>
          invoice.status !== "cancelled" &&
          invoice.date >= dateFrom &&
          invoice.date <= dateTo &&
          !closedInvoiceIds.has(invoice.id)
      )
      .sort((a, b) => a.date.localeCompare(b.date) || a.invoiceNumber.localeCompare(b.invoiceNumber));
    const map = new Map<string, InvoiceGroup>();
    for (const invoice of eligible) {
      const company = insuranceCompanies.find((item) => item.id === invoice.insuranceCompanyId);
      const split = reportSettings.splitDepartments;
      const departmentId = split ? invoice.serviceDepartmentId : null;
      const departmentName = split ? invoice.serviceDepartmentName : null;
      const currency = invoiceCurrency(invoice);
      const key = [invoice.insuranceCompanyId, departmentId ?? "all", currency].join(":");
      const existing = map.get(key);
      if (existing) {
        existing.invoices.push(invoice);
      } else {
        map.set(key, {
          key,
          companyId: invoice.insuranceCompanyId,
          companyName: company?.name ?? invoice.insuranceCompanyName,
          departmentId,
          departmentName,
          currency,
          invoices: [invoice],
        });
      }
    }
    return [...map.values()].sort(
      (a, b) =>
        a.companyName.localeCompare(b.companyName) ||
        (a.departmentName ?? "").localeCompare(b.departmentName ?? "") ||
        a.currency.localeCompare(b.currency)
    );
  }, [
    invoices,
    closedInvoiceIds,
    insuranceCompanies,
    dateFrom,
    dateTo,
    reportSettings.splitDepartments,
  ]);

  const groupedByCurrency = useMemo(() => {
    const totals = new Map<string, number>();
    for (const group of grouped) {
      totals.set(
        group.currency,
        (totals.get(group.currency) ?? 0) +
          group.invoices.reduce((sum, invoice) => sum + invoice.netAmount, 0)
      );
    }
    return [...totals.entries()];
  }, [grouped]);

  async function shareCsv(group: InvoiceGroup) {
    const lines = [
      ["رقم الفاتورة", "التاريخ", "المشترك", "الكود", "جهة العمل", "القسم", "مبلغ الفاتورة", "التحمل", "الخصم", "صافي المطالبة"].join(","),
      ...group.invoices.map((invoice) =>
        [
          invoice.invoiceNumber,
          invoice.date,
          invoice.subscriberName,
          invoice.subscriberId,
          invoice.employerName,
          invoice.serviceDepartmentName,
          invoice.totalAmount,
          invoice.coinsuranceAmount,
          invoice.discountAmount,
          invoice.netAmount,
        ]
          .map((value) => `"${String(value).replaceAll('"', '""')}"`)
          .join(",")
      ),
      `,,,,,,,,,"${group.invoices.reduce((sum, invoice) => sum + invoice.netAmount, 0)}"`,
    ];
    await Share.share({
      title: `تقرير ${group.companyName}`,
      message: lines.join("\n"),
    });
  }

  async function handleClose() {
    setError("");
    setSuccess("");
    if (!grouped.length) {
      setError("لا توجد فواتير مفتوحة ضمن هذه المدة.");
      return;
    }
    setSaving(true);
    const prepared: PeriodicReport[] = grouped.map((group) => ({
      id: generateId(),
      kind: "periodic",
      companyId: group.companyId,
      companyName: group.companyName,
      departmentId: group.departmentId,
      departmentName: group.departmentName,
      currency: group.currency,
      dateFrom,
      dateTo,
      closedAt: new Date().toISOString(),
      invoiceIds: group.invoices.map((invoice) => invoice.id),
      totalAmount: group.invoices.reduce((sum, invoice) => sum + invoice.netAmount, 0),
      settlements: [],
      rejections: [],
    }));
    try {
      await closeReports(prepared);
      setSuccess(`أُغلق ${prepared.length} تقريرًا وربطت به ${prepared.reduce((sum, report) => sum + report.invoiceIds.length, 0)} فاتورة. لن تظهر هذه الفواتير في دورة أخرى.`);
      setConfirmClose(false);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "تعذر إغلاق التقارير.");
    } finally {
      setSaving(false);
    }
  }

  const firstInvoice = grouped.flatMap((group) => group.invoices).sort((a, b) => a.date.localeCompare(b.date))[0];
  const lastInvoice = grouped.flatMap((group) => group.invoices).sort((a, b) => b.date.localeCompare(a.date))[0];
  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;
  const datesValid =
    /^\d{4}-\d{2}-\d{2}$/.test(dateFrom) &&
    /^\d{4}-\d{2}-\d{2}$/.test(dateTo) &&
    dateFrom <= dateTo;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} accessibilityLabel="رجوع">
          <Feather name="arrow-right" size={23} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>التقارير الدورية</Text>
        <Pressable onPress={() => router.push("/report-settings")} accessibilityLabel="إعدادات التقارير">
          <Feather name="settings" size={20} color={colors.primary} />
        </Pressable>
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.card}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>الفترة المراد تجهيزها</Text>
          <Text style={[styles.help, { color: colors.mutedForeground }]}>
            الدورة الافتراضية {reportSettings.cadence === "monthly" ? "شهرية" : reportSettings.cadence === "weekly" ? "أسبوعية" : `${reportSettings.customCycleDays} يومًا`}. عدّل التاريخين قبل المعاينة عند الحاجة.
          </Text>
          <Input label="من (YYYY-MM-DD)" value={dateFrom} onChangeText={(value) => { setDateFrom(value); setConfirmClose(false); setSuccess(""); }} placeholder="2026-01-01" />
          <Input label="إلى (YYYY-MM-DD)" value={dateTo} onChangeText={(value) => { setDateTo(value); setConfirmClose(false); setSuccess(""); }} placeholder={todayKey()} />
          {!datesValid && <Text style={[styles.error, { color: colors.destructive }]}>أدخل تاريخين بصيغة YYYY-MM-DD، ويجب أن يكون تاريخ البداية قبل النهاية.</Text>}
          <View style={[styles.settingPill, { backgroundColor: colors.secondary }]}>
            <Feather name={reportSettings.splitDepartments ? "grid" : "briefcase"} size={15} color={colors.primary} />
            <Text style={[styles.settingPillText, { color: colors.secondaryForeground }]}>
              {reportSettings.splitDepartments ? "تقرير مستقل لكل شركة وقسم وعملة" : "تقرير لكل شركة، والأقسام مدمجة، مع فصل العملات"}
            </Text>
          </View>
        </Card>

        <View style={styles.previewTitleRow}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>معاينة الفواتير غير المغلقة</Text>
          <Text style={[styles.counter, { color: colors.primary, backgroundColor: colors.secondary }]}>
            {grouped.reduce((sum, group) => sum + group.invoices.length, 0)}
          </Text>
        </View>
        {grouped.length === 0 ? (
          <Card style={styles.empty}>
            <Feather name="check-circle" size={23} color={colors.success} />
            <Text style={[styles.emptyText, { color: colors.foreground }]}>
              لا توجد فواتير غير مغلقة ضمن هذه الفترة.
            </Text>
          </Card>
        ) : (
          grouped.map((group) => (
            <Card key={group.key} style={styles.groupCard}>
              <View style={styles.groupHeader}>
                <View style={{ alignItems: "flex-start" }}>
                  <Text style={[styles.groupTotal, { color: colors.primary }]}>
                    {formatMoney(group.invoices.reduce((sum, invoice) => sum + invoice.netAmount, 0), group.currency)}
                  </Text>
                  <Text style={[styles.groupMeta, { color: colors.mutedForeground }]}>
                    {group.invoices.length} فاتورة · {group.currency}
                  </Text>
                </View>
                <View style={{ flex: 1, alignItems: "flex-end" }}>
                  <Text style={[styles.companyTitle, { color: colors.foreground }]}>{group.companyName}</Text>
                  {group.departmentName ? <Text style={[styles.groupMeta, { color: colors.mutedForeground }]}>{group.departmentName}</Text> : null}
                </View>
              </View>
              {group.invoices.map((invoice) => (
                <Pressable
                  key={invoice.id}
                  onPress={() => router.push(`/invoice/${invoice.id}` as any)}
                  style={[styles.invoiceRow, { borderTopColor: colors.border }]}
                >
                  <Text style={[styles.invoiceAmount, { color: colors.foreground }]}>{formatMoney(invoice.netAmount, group.currency)}</Text>
                  <View style={{ alignItems: "flex-end", flex: 1 }}>
                    <Text style={[styles.invoiceName, { color: colors.foreground }]}>{invoice.subscriberName}</Text>
                    <Text style={[styles.groupMeta, { color: colors.mutedForeground }]}>{invoice.invoiceNumber} · {invoice.date}</Text>
                  </View>
                  <Feather name="chevron-left" size={15} color={colors.mutedForeground} />
                </Pressable>
              ))}
              <Pressable onPress={() => void shareCsv(group)} style={styles.shareButton}>
                <Feather name="share-2" size={15} color={colors.primary} />
                <Text style={[styles.shareText, { color: colors.primary }]}>مشاركة معاينة CSV</Text>
              </Pressable>
            </Card>
          ))
        )}

        {grouped.length > 0 && (
          <>
            <Card style={styles.card}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>مراجعة الإغلاق</Text>
              <Text style={[styles.confirmLine, { color: colors.foreground }]}>من: {dateFrom} · إلى: {dateTo}</Text>
              <Text style={[styles.confirmLine, { color: colors.foreground }]}>أول فاتورة: {firstInvoice?.invoiceNumber} · {firstInvoice?.date} · {firstInvoice?.subscriberName}</Text>
              <Text style={[styles.confirmLine, { color: colors.foreground }]}>آخر فاتورة: {lastInvoice?.invoiceNumber} · {lastInvoice?.date} · {lastInvoice?.subscriberName}</Text>
              <Text style={[styles.confirmLine, { color: colors.foreground }]}>عدد التقارير: {grouped.length}</Text>
              {groupedByCurrency.map(([currency, total]) => (
                <Text key={currency} style={[styles.confirmTotal, { color: colors.primary }]}>
                  إجمالي المطالبة ({currency}): {formatMoney(total, currency as any)}
                </Text>
              ))}
              {!confirmClose ? (
                <Button title="مراجعة ثم إغلاق الفترة" onPress={() => { setConfirmClose(true); setError(""); }} />
              ) : (
                <>
                  <Text style={[styles.warningText, { color: colors.warning }]}>
                    بعد التأكيد، لن تدخل هذه الفواتير في تقرير دوري آخر. تأكد من النطاق وأول وآخر فاتورة.
                  </Text>
                  <View style={styles.actions}>
                    <Button title="العودة للمراجعة" onPress={() => setConfirmClose(false)} variant="ghost" style={{ flex: 1 }} />
                    <Button title="تأكيد الإغلاق" onPress={() => void handleClose()} loading={saving} style={{ flex: 1 }} />
                  </View>
                </>
              )}
            </Card>
          </>
        )}
        {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
        {success ? (
          <Card style={[styles.successCard, { backgroundColor: colors.success + "12", borderColor: colors.success + "40" }]}>
            <Feather name="check-circle" size={18} color={colors.success} />
            <Text style={[styles.successText, { color: colors.success }]}>{success}</Text>
          </Card>
        ) : null}
        <Text style={[styles.help, { color: colors.mutedForeground }]}>
          الإغلاق يدوي بعد المراجعة. مشاركة CSV لا تؤكد رفعه لشركة التأمين، ولا تُغلق الفترة تلقائيًا.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 14 },
  card: { gap: 10 },
  cardTitle: { textAlign: "right", fontSize: 15, fontFamily: "Inter_700Bold" },
  help: { textAlign: "right", fontSize: 11, lineHeight: 18, fontFamily: "Inter_400Regular" },
  error: { textAlign: "right", fontSize: 12, lineHeight: 18, fontFamily: "Inter_500Medium" },
  settingPill: { flexDirection: "row-reverse", alignItems: "center", gap: 8, padding: 10, borderRadius: 10 },
  settingPillText: { flex: 1, textAlign: "right", fontSize: 11, fontFamily: "Inter_500Medium" },
  previewTitleRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  sectionTitle: { flex: 1, textAlign: "right", fontSize: 15, fontFamily: "Inter_700Bold" },
  counter: { borderRadius: 8, overflow: "hidden", paddingHorizontal: 9, paddingVertical: 4, fontSize: 12, fontFamily: "Inter_700Bold" },
  empty: { alignItems: "center", gap: 8, padding: 22 },
  emptyText: { textAlign: "center", fontFamily: "Inter_500Medium", fontSize: 13 },
  groupCard: { gap: 8 },
  groupHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  groupTotal: { fontSize: 15, fontFamily: "Inter_700Bold" },
  groupMeta: { fontSize: 10, fontFamily: "Inter_400Regular", textAlign: "right" },
  companyTitle: { fontSize: 14, fontFamily: "Inter_700Bold", textAlign: "right" },
  invoiceRow: { flexDirection: "row-reverse", alignItems: "center", gap: 7, paddingTop: 8, borderTopWidth: 1 },
  invoiceAmount: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  invoiceName: { fontSize: 12, fontFamily: "Inter_500Medium" },
  shareButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, paddingTop: 6 },
  shareText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  confirmLine: { fontSize: 12, textAlign: "right", lineHeight: 18, fontFamily: "Inter_400Regular" },
  confirmTotal: { fontSize: 13, textAlign: "right", fontFamily: "Inter_700Bold" },
  warningText: { fontSize: 12, textAlign: "right", lineHeight: 18, fontFamily: "Inter_500Medium" },
  actions: { flexDirection: "row", gap: 10 },
  successCard: { flexDirection: "row-reverse", alignItems: "center", gap: 8, borderWidth: 1 },
  successText: { flex: 1, textAlign: "right", fontSize: 12, lineHeight: 18, fontFamily: "Inter_500Medium" },
});

