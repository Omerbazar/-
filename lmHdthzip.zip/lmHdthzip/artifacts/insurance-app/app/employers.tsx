import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp, generateId, Employer, EmployerSection, CoinsuranceRate } from "@/context/AppContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { EmptyState } from "@/components/ui/EmptyState";
import { Badge } from "@/components/ui/Badge";

export default function EmployersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { employers, insuranceCompanies, addEmployer, updateEmployer, deleteEmployer } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingEmployer, setEditingEmployer] = useState<Employer | null>(null);
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [phone, setPhone] = useState("");
  const [selectedCompanyId, setSelectedCompanyId] = useState("");
  const [sections, setSections] = useState<EmployerSection[]>([]);
  const [newSectionName, setNewSectionName] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [expandedSectionId, setExpandedSectionId] = useState<string | null>(null);

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  function openNew() {
    setEditingEmployer(null);
    setCode("");
    setName("");
    setLocation("");
    setPhone("");
    setSelectedCompanyId("");
    setSections([{ id: generateId(), name: "أساسي", rates: [] }]);
    setNewSectionName("");
    setShowModal(true);
  }

  function openEdit(emp: Employer) {
    setEditingEmployer(emp);
    setCode(emp.code);
    setName(emp.name);
    setLocation(emp.location);
    setPhone(emp.phone);
    setSelectedCompanyId(emp.insuranceCompanyId);
    setSections(emp.sections);
    setShowModal(true);
  }

  function addSection() {
    if (!newSectionName.trim()) return;
    setSections((prev) => [
      ...prev,
      { id: generateId(), name: newSectionName.trim(), rates: [] },
    ]);
    setNewSectionName("");
  }

  function removeSection(id: string) {
    setSections((prev) => prev.filter((s) => s.id !== id));
  }

  function addRate(sectionId: string, rateName: string, percent: string, ceiling: string) {
    if (!rateName || !percent) return;
    const rate: CoinsuranceRate = {
      id: generateId(),
      name: rateName,
      percent: parseFloat(percent),
      ceiling: ceiling ? parseFloat(ceiling) : 0,
      notes: "",
      active: true,
    };
    setSections((prev) =>
      prev.map((s) =>
        s.id === sectionId ? { ...s, rates: [...s.rates, rate] } : s
      )
    );
  }

  function removeRate(sectionId: string, rateId: string) {
    setSections((prev) =>
      prev.map((s) =>
        s.id === sectionId
          ? { ...s, rates: s.rates.filter((r) => r.id !== rateId) }
          : s
      )
    );
  }

  async function handleSave() {
    if (!name.trim()) return;
    const employer: Employer = {
      id: editingEmployer?.id ?? generateId(),
      code,
      name,
      location,
      phone,
      insuranceCompanyId: selectedCompanyId,
      sections,
    };
    if (editingEmployer) {
      await updateEmployer(employer);
    } else {
      await addEmployer(employer);
    }
    setShowModal(false);
  }

  async function handleDelete(id: string) {
    Alert.alert("حذف جهة العمل", "هل أنت متأكد؟", [
      { text: "إلغاء" },
      { text: "حذف", style: "destructive", onPress: () => deleteEmployer(id) },
    ]);
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          { paddingTop: topPt + 16, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()}>
            <Feather name="arrow-right" size={24} color={colors.foreground} />
          </Pressable>
          <Pressable
            onPress={openNew}
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
          >
            <Feather name="plus" size={20} color="#fff" />
          </Pressable>
          <Text style={[styles.title, { color: colors.foreground }]}>
            جهات العمل
          </Text>
        </View>
      </View>

      <FlatList
        data={employers}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.list,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
        ListEmptyComponent={
          <EmptyState icon="briefcase" title="لا توجد جهات عمل" subtitle="اضغط + لإضافة جهة عمل" />
        }
        renderItem={({ item }) => {
          const company = insuranceCompanies.find((c) => c.id === item.insuranceCompanyId);
          const isExpanded = expandedId === item.id;
          return (
            <Card style={styles.card}>
              <Pressable onPress={() => setExpandedId(isExpanded ? null : item.id)} style={styles.cardHeader}>
                <View style={{ flexDirection: "row", gap: 8 }}>
                  <Pressable onPress={() => openEdit(item)}>
                    <Feather name="edit-2" size={16} color={colors.primary} />
                  </Pressable>
                  <Pressable onPress={() => handleDelete(item.id)}>
                    <Feather name="trash-2" size={16} color={colors.destructive} />
                  </Pressable>
                </View>
                <View style={{ flex: 1, alignItems: "flex-end" }}>
                  <Text style={[styles.employerName, { color: colors.foreground }]}>{item.name}</Text>
                  {company && (
                    <Text style={[styles.meta, { color: colors.mutedForeground }]}>{company.name}</Text>
                  )}
                </View>
                <View style={[styles.empIcon, { backgroundColor: colors.primary + "18" }]}>
                  <Feather name="briefcase" size={20} color={colors.primary} />
                </View>
              </Pressable>
              {isExpanded && item.sections.map((sec) => (
                <View key={sec.id} style={[styles.sectionItem, { backgroundColor: colors.muted, borderRadius: 10 }]}>
                  <Text style={[styles.sectionName, { color: colors.foreground }]}>{sec.name}</Text>
                  {sec.rates.map((r) => (
                    <View key={r.id} style={styles.rateRow}>
                      <Text style={[styles.ratePct, { color: colors.primary }]}>{r.percent}%</Text>
                      <Text style={[styles.rateName, { color: colors.foreground }]}>{r.name}</Text>
                    </View>
                  ))}
                </View>
              ))}
            </Card>
          );
        }}
      />

      <Modal visible={showModal} animationType="slide" presentationStyle="pageSheet">
        <EmployerForm
          code={code} setCode={setCode}
          name={name} setName={setName}
          location={location} setLocation={setLocation}
          phone={phone} setPhone={setPhone}
          selectedCompanyId={selectedCompanyId} setSelectedCompanyId={setSelectedCompanyId}
          sections={sections} setSections={setSections}
          newSectionName={newSectionName} setNewSectionName={setNewSectionName}
          insuranceCompanies={insuranceCompanies}
          onAddSection={addSection}
          onRemoveSection={removeSection}
          onAddRate={addRate}
          onRemoveRate={removeRate}
          onSave={handleSave}
          onCancel={() => setShowModal(false)}
          isEditing={!!editingEmployer}
          colors={colors}
          insets={insets}
          expandedSectionId={expandedSectionId}
          setExpandedSectionId={setExpandedSectionId}
        />
      </Modal>
    </View>
  );
}

function EmployerForm({
  code, setCode, name, setName, location, setLocation, phone, setPhone,
  selectedCompanyId, setSelectedCompanyId, sections, newSectionName,
  setNewSectionName, insuranceCompanies, onAddSection, onRemoveSection,
  onAddRate, onRemoveRate, onSave, onCancel, isEditing, colors, insets,
  expandedSectionId, setExpandedSectionId,
}: any) {
  const [rateForms, setRateForms] = useState<Record<string, { name: string; percent: string; ceiling: string }>>({});

  function getRateForm(sectionId: string) {
    return rateForms[sectionId] ?? { name: "", percent: "", ceiling: "" };
  }

  function setRateForm(sectionId: string, field: string, value: string) {
    setRateForms((prev: any) => ({
      ...prev,
      [sectionId]: { ...getRateForm(sectionId), [field]: value },
    }));
  }

  function handleAddRate(sectionId: string) {
    const form = getRateForm(sectionId);
    onAddRate(sectionId, form.name, form.percent, form.ceiling);
    setRateForms((prev: any) => ({ ...prev, [sectionId]: { name: "", percent: "", ceiling: "" } }));
  }

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[{ flex: 1, backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          { paddingTop: topPt + 16, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <View style={styles.headerRow}>
          <Button title="إلغاء" onPress={onCancel} variant="ghost" size="sm" />
          <Text style={[styles.title, { color: colors.foreground }]}>
            {isEditing ? "تعديل جهة عمل" : "جهة عمل جديدة"}
          </Text>
          <Button title="حفظ" onPress={onSave} size="sm" />
        </View>
      </View>
      <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 80 }}>
        <Card style={{ gap: 12 }}>
          <Text style={[styles.sectionName, { color: colors.foreground, fontSize: 15, marginBottom: 4 }]}>البيانات الأساسية</Text>
          <Input label="كود الجهة" value={code} onChangeText={setCode} placeholder="001" />
          <Input label="اسم الجهة *" value={name} onChangeText={setName} placeholder="اسم جهة العمل" />
          <Input label="الموقع" value={location} onChangeText={setLocation} placeholder="المدينة" />
          <Input label="رقم التواصل" value={phone} onChangeText={setPhone} placeholder="05xxxxxxxx" keyboardType="phone-pad" />
        </Card>
        <Card style={{ gap: 12 }}>
          <Text style={[styles.sectionName, { color: colors.foreground, fontSize: 15 }]}>شركة التأمين</Text>
          <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }}>
            {insuranceCompanies.map((c: any) => (
              <Pressable
                key={c.id}
                onPress={() => setSelectedCompanyId(c.id)}
                style={[styles.chip, { backgroundColor: selectedCompanyId === c.id ? colors.primary : colors.card, borderColor: selectedCompanyId === c.id ? colors.primary : colors.border }]}
              >
                <Text style={{ color: selectedCompanyId === c.id ? "#fff" : colors.foreground, fontFamily: "Inter_500Medium", fontSize: 13 }}>{c.name}</Text>
              </Pressable>
            ))}
          </View>
        </Card>
        <Card style={{ gap: 12 }}>
          <Text style={[styles.sectionName, { color: colors.foreground, fontSize: 15 }]}>الأقسام التأمينية</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <Button title="إضافة قسم" onPress={onAddSection} size="sm" style={{ flex: 1 }} />
            <View style={{ flex: 2 }}>
              <Input value={newSectionName} onChangeText={setNewSectionName} placeholder="اسم القسم (أساسي، VIP...)" />
            </View>
          </View>
          {sections.map((sec: any) => (
            <View key={sec.id} style={[{ borderRadius: 12, overflow: "hidden", borderWidth: 1, borderColor: colors.border }]}>
              <Pressable
                onPress={() => setExpandedSectionId(expandedSectionId === sec.id ? null : sec.id)}
                style={[{ backgroundColor: colors.muted, padding: 12, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }]}
              >
                <Text style={[styles.sectionName, { color: colors.foreground }]}>{sec.name}</Text>
                <View style={{ flexDirection: "row", gap: 12, alignItems: "center" }}>
                  <Text style={[{ color: colors.mutedForeground, fontSize: 12, fontFamily: "Inter_400Regular" }]}>{sec.rates.length} نسبة</Text>
                  <Pressable onPress={() => onRemoveSection(sec.id)}>
                    <Feather name="x" size={16} color={colors.destructive} />
                  </Pressable>
                </View>
              </Pressable>
              {expandedSectionId === sec.id && (
                <View style={{ padding: 12, gap: 8, backgroundColor: colors.card }}>
                  {sec.rates.map((r: any) => (
                    <View key={r.id} style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingVertical: 4 }}>
                      <Pressable onPress={() => onRemoveRate(sec.id, r.id)}>
                        <Feather name="trash-2" size={14} color={colors.destructive} />
                      </Pressable>
                      <Text style={{ color: colors.primary, fontFamily: "Inter_700Bold" }}>{r.percent}%</Text>
                      <Text style={{ color: colors.foreground, fontFamily: "Inter_500Medium", flex: 1, textAlign: "right", marginHorizontal: 8 }}>{r.name}</Text>
                    </View>
                  ))}
                  <View style={{ gap: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: colors.border }}>
                    <Input value={getRateForm(sec.id).name} onChangeText={(v) => setRateForm(sec.id, "name", v)} placeholder="اسم النسبة (أدوية، مختبر...)" />
                    <View style={{ flexDirection: "row", gap: 8 }}>
                      <Input value={getRateForm(sec.id).percent} onChangeText={(v) => setRateForm(sec.id, "percent", v)} placeholder="النسبة %" keyboardType="numeric" containerStyle={{ flex: 1 }} />
                      <Input value={getRateForm(sec.id).ceiling} onChangeText={(v) => setRateForm(sec.id, "ceiling", v)} placeholder="السقف" keyboardType="numeric" containerStyle={{ flex: 1 }} />
                    </View>
                    <Button title="إضافة نسبة" onPress={() => handleAddRate(sec.id)} size="sm" variant="secondary" />
                  </View>
                </View>
              )}
            </View>
          ))}
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: { paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1, gap: 12 },
  headerRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  title: { fontSize: 20, fontFamily: "Inter_700Bold" },
  addBtn: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  list: { paddingHorizontal: 16, paddingTop: 12, gap: 8 },
  card: { gap: 8 },
  cardHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  empIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  employerName: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  meta: { fontSize: 12, fontFamily: "Inter_400Regular" },
  sectionItem: { padding: 10, gap: 4 },
  sectionName: { fontSize: 14, fontFamily: "Inter_600SemiBold", textAlign: "right" },
  rateRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, paddingVertical: 2 },
  ratePct: { fontSize: 14, fontFamily: "Inter_700Bold" },
  rateName: { fontSize: 13, fontFamily: "Inter_400Regular" },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 100, borderWidth: 1 },
});
