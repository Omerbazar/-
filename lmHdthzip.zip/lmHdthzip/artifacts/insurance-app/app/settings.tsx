import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp, Department, CurrencyCode, generateId } from "@/context/AppContext";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { CURRENCIES } from "@/constants/currencies";

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { entity, updateEntity } = useApp();

  const [name, setName] = useState(entity.name);
  const [address, setAddress] = useState(entity.address);
  const [phone, setPhone] = useState(entity.phone);
  const [email, setEmail] = useState(entity.email);
  const [website, setWebsite] = useState(entity.website);
  const [baseCurrency, setBaseCurrency] = useState<CurrencyCode | null>(
    entity.baseCurrency
  );
  const [departments, setDepartments] = useState<Department[]>(entity.departments);
  const [newDeptName, setNewDeptName] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [saved, setSaved] = useState(false);

  function addDept() {
    const trimmedName = newDeptName.trim();
    if (!trimmedName) {
      setFormError("أدخل اسم القسم أولًا.");
      return;
    }

    const duplicate = departments.find(
      (department) =>
        department.name.trim().toLocaleLowerCase() ===
        trimmedName.toLocaleLowerCase()
    );
    if (duplicate) {
      setFormError(
        duplicate.active === false
          ? "هذا القسم موجود لكنه متوقف؛ أعد تفعيله من القائمة."
          : "يوجد قسم بهذا الاسم بالفعل."
      );
      return;
    }

    setFormError("");
    setSaved(false);
    setDepartments((prev) => [
      ...prev,
      { id: generateId(), name: trimmedName, phone: "", active: true },
    ]);
    setNewDeptName("");
  }

  function toggleDept(id: string) {
    setFormError("");
    setSaved(false);
    setDepartments((prev) =>
      prev.map((department) =>
        department.id === id
          ? { ...department, active: department.active === false }
          : department
      )
    );
  }

  async function handleSave() {
    setFormError("");
    setSaved(false);
    if (!name.trim()) {
      setFormError("اسم المنشأة مطلوب.");
      return;
    }
    if (!baseCurrency) {
      setFormError("اختر العملة الأساسية قبل الحفظ.");
      return;
    }
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setFormError("تحقق من صيغة البريد الإلكتروني.");
      return;
    }

    setSaving(true);
    try {
      await updateEntity({
        ...entity,
        name: name.trim(),
        address: address.trim(),
        phone: phone.trim(),
        email: email.trim(),
        website: website.trim(),
        baseCurrency,
        departments: departments.map((department) => ({
          ...department,
          name: department.name.trim(),
          phone: department.phone.trim(),
        })),
      });
      setSaved(true);
    } catch {
      setFormError("تعذر حفظ الإعدادات. تحقق من البيانات ثم أعد المحاولة.");
    } finally {
      setSaving(false);
    }
  }

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { paddingTop: topPt + 12, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <Pressable onPress={() => router.back()}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]}>
          إعدادات المنشأة
        </Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            بيانات المنشأة
          </Text>
          <Input label="اسم المنشأة *" value={name} onChangeText={setName} placeholder="اسم المستشفى أو الصيدلية" />
          <Input label="العنوان" value={address} onChangeText={setAddress} placeholder="المدينة، الحي" />
          <Input label="رقم التواصل" value={phone} onChangeText={setPhone} placeholder="05xxxxxxxx" keyboardType="phone-pad" />
          <Input label="البريد الإلكتروني" value={email} onChangeText={setEmail} placeholder="info@clinic.com" keyboardType="email-address" />
          <Input label="الموقع الإلكتروني" value={website} onChangeText={setWebsite} placeholder="www.clinic.com" />
        </Card>

        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            العملة الأساسية *
          </Text>
          <Text style={[styles.helpText, { color: colors.mutedForeground }]}>
            تُستخدم افتراضيًا للفواتير الجديدة. عند اختيار عملة مختلفة في الفاتورة أدخل سعر صرفها يدويًا. الفواتير القديمة تُحفظ كما كانت بالريال السعودي ولا تتحول تلقائيًا عند تغيير هذا الخيار.
          </Text>
          <View style={styles.currencyGroup}>
            {CURRENCIES.map((currency) => {
              const selected = baseCurrency === currency.code;
              return (
                <Pressable
                  key={currency.code}
                  accessibilityRole="radio"
                  accessibilityState={{ selected }}
                  onPress={() => {
                    setBaseCurrency(currency.code);
                    setFormError("");
                    setSaved(false);
                  }}
                  style={[
                    styles.currencyOption,
                    {
                      backgroundColor: selected ? colors.secondary : colors.card,
                      borderColor: selected ? colors.primary : colors.border,
                    },
                  ]}
                >
                  <Feather
                    name={selected ? "check-circle" : "circle"}
                    size={18}
                    color={selected ? colors.primary : colors.mutedForeground}
                  />
                  <Text style={[styles.currencyText, { color: colors.foreground }]}>
                    {currency.label} ({currency.code})
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </Card>

        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            الأقسام
          </Text>
          <Text style={[styles.helpText, { color: colors.mutedForeground }]}>
            إيقاف القسم يمنع اختياره في الفواتير الجديدة، مع الاحتفاظ به للرجوع إلى السجلات السابقة.
          </Text>
          {departments.map((dept) => (
            <View key={dept.id} style={[styles.deptRow, { borderBottomColor: colors.border }]}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={dept.active === false ? `تفعيل ${dept.name}` : `إيقاف ${dept.name}`}
                onPress={() => toggleDept(dept.id)}
              >
                <Text
                  style={[
                    styles.departmentAction,
                    { color: dept.active === false ? colors.primary : colors.destructive },
                  ]}
                >
                  {dept.active === false ? "تفعيل" : "إيقاف"}
                </Text>
              </Pressable>
              <Text style={[styles.deptName, { color: colors.foreground }]}>
                {dept.name}
              </Text>
              <Feather
                name={dept.active === false ? "grid" : "check-square"}
                size={16}
                color={dept.active === false ? colors.mutedForeground : colors.primary}
              />
            </View>
          ))}
          <View style={styles.addDeptRow}>
            <Button title="إضافة" onPress={addDept} size="sm" style={{ paddingHorizontal: 20 }} />
            <View style={{ flex: 1 }}>
              <Input
                value={newDeptName}
                onChangeText={setNewDeptName}
                placeholder="اسم القسم الجديد..."
              />
            </View>
          </View>
        </Card>

        {formError ? (
          <Text accessibilityRole="alert" style={[styles.formMessage, { color: colors.destructive }]}>
            {formError}
          </Text>
        ) : null}
        {saved ? (
          <Text style={[styles.formMessage, { color: colors.success }]}>
            تم حفظ الإعدادات على هذا الجهاز.
          </Text>
        ) : null}
        <Button title="حفظ الإعدادات" onPress={handleSave} loading={saving} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  title: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 16 },
  section: { gap: 12 },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold", textAlign: "right", marginBottom: 4 },
  helpText: { fontSize: 12, lineHeight: 19, textAlign: "right" },
  currencyGroup: { gap: 8 },
  currencyOption: {
    minHeight: 48,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  currencyText: { flex: 1, textAlign: "right", fontSize: 14, fontFamily: "Inter_500Medium" },
  formMessage: { textAlign: "right", fontSize: 13, fontFamily: "Inter_500Medium" },
  departmentAction: { fontSize: 12, fontFamily: "Inter_600SemiBold", padding: 5 },
  deptRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  deptName: { flex: 1, fontSize: 14, fontFamily: "Inter_500Medium", textAlign: "right", marginHorizontal: 10 },
  addDeptRow: { flexDirection: "row", gap: 8, alignItems: "center" },
});
