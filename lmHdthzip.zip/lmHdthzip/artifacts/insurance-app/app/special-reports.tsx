import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { Share } from "react-native";
import React, { useMemo, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatMoney, invoiceCurrency } from "@/utils/accounting";

type SortKey = "date" | "name" | "amount";

function todayKey() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export default function SpecialReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    invoices,
    insuranceCompanies,
    entity,
    subscribers,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
  } = useApp();
  const [dateFrom, setDateFrom] = useState(() => `${todayKey().slice(0, 7)}-01`);
  const [dateTo, setDateTo] = useState(todayKey);
  const [companyId, setCompanyId] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortKey>("date");
  const [includeCancelled, setIncludeCancelled] = useState(false);

  const filtered = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    const rows = invoices.filter((invoice) => {
      if (dateFrom && invoice.date < dateFrom) return false;
      if (dateTo && invoice.date > dateTo) return false;
      if (companyId && invoice.insuranceCompanyId !== companyId) return false;
      if (departmentId && invoice.serviceDepartmentId !== departmentId) return false;
      if (!includeCancelled && invoice.status === "cancelled") return false;
      if (query) {
        const subscriber = subscribers.find((item) => item.id === invoice.subscriberId);
        const content = [
          invoice.invoiceNumber,
          invoice.subscriberName,
          invoice.employerName,
          invoice.insuranceCompanyName,
          invoice.serviceDepartmentName,
          subscriber?.cardCode ?? "",
          subscriber?.phone ?? "",
        ]
          .join(" ")
          .toLocaleLowerCase();
        if (!content.includes(query)) return false;
      }
      return true;
    });
    return rows.sort((a, b) => {
      if (sort === "name") return a.subscriberName.localeCompare(b.subscriberName);
      if (sort === "amount") return b.netAmount - a.netAmount;
      return b.date.localeCompare(a.date) || b.invoiceNumber.localeCompare(a.invoiceNumber);
    });
  }, [
    invoices,
    subscribers,
    dateFrom,
    dateTo,
    companyId,
    departmentId,
    search,
    sort,
    includeCancelled,
  ]);

  async function shareCsv() {
    const columns = [
      "رقم الفاتورة",
      "التاريخ",
      "المشترك",
      "كود البطاقة",
      "جهة العمل",
      "شركة التأمين",
      "القسم",
      "العملة",
      "الإجمالي",
      "التحمل",
      "الخصم",
      "الصافي",
      "المحصل",
      "المرفوض",
      "المتبقي",
      "الحالة",
      "الملاحظات",
    ];
    const escape = (value: unknown) =>
      `"${String(value ?? "").replaceAll('"', '""')}"`;
    const data = filtered.map((invoice) => {
      const currency = invoiceCurrency(invoice);
      const paid = getInvoicePaidAmount(invoice.id);
      const rejected = getInvoiceRejectedAmount(invoice.id);
      const subscriber = subscribers.find((item) => item.id === invoice.subscriberId);
      return [
        invoice.invoiceNumber,
        invoice.date,
        invoice.subscriberName,
        subscriber?.cardCode ?? "",
        invoice.employerName,
        invoice.insuranceCompanyName,
        invoice.serviceDepartmentName,
        currency,
        invoice.totalAmount,
        invoice.coinsuranceAmount,
        invoice.discountAmount,
        invoice.netAmount,
        paid,
        rejected,
        Math.max(0, invoice.netAmount - paid - rejected),
        invoice.status,
        invoice.notes ?? "",
      ]
        .map(escape)
        .join(",");
    });
    await Share.share({
      title: "تقرير مخصص",
      message: [columns.map(escape).join(","), ...data].join("\n"),
    });
  }

  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;
  const sortOptions: { key: SortKey; label: string }[] = [
    { key: "date", label: "التاريخ" },
    { key: "name", label: "الاسم" },
    { key: "amount", label: "المبلغ" },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} accessibilityLabel="رجوع">
          <Feather name="arrow-right" size={23} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>تقارير خاصة</Text>
        <Pressable onPress={() => void shareCsv()} accessibilityLabel="مشاركة التقرير">
          <Feather name="share-2" size={19} color={colors.primary} />
        </Pressable>
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <Card style={styles.card}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>تحديد النطاق</Text>
          <Text style={[styles.help, { color: colors.mutedForeground }]}>
            هذا تقرير استعلام ومشاركة فقط؛ لا يغلق الفواتير ولا يغيّر أرصدة الشركات.
          </Text>
          <Input label="من (YYYY-MM-DD)" value={dateFrom} onChangeText={setDateFrom} placeholder="2026-01-01" />
          <Input label="إلى (YYYY-MM-DD)" value={dateTo} onChangeText={setDateTo} placeholder={todayKey()} />
          <Input
            label="المشترك أو كود البطاقة أو جهة العمل"
            value={search}
            onChangeText={setSearch}
            placeholder="اكتب اسمًا أو كودًا للبحث"
          />
          <Text style={[styles.fieldTitle, { color: colors.foreground }]}>شركة التأمين</Text>
          <View style={styles.chips}>
            {[{ id: "", name: "كل الشركات" }, ...insuranceCompanies].map((company) => (
              <FilterChip key={company.id || "all-companies"} selected={companyId === company.id} label={company.name} onPress={() => setCompanyId(company.id)} />
            ))}
          </View>
          <Text style={[styles.fieldTitle, { color: colors.foreground }]}>القسم</Text>
          <View style={styles.chips}>
            {[{ id: "", name: "كل الأقسام" }, ...entity.departments].map((department) => (
              <FilterChip key={department.id || "all-departments"} selected={departmentId === department.id} label={department.name} onPress={() => setDepartmentId(department.id)} />
            ))}
          </View>
          <Text style={[styles.fieldTitle, { color: colors.foreground }]}>ترتيب الصفوف</Text>
          <View style={styles.chips}>
            {sortOptions.map((option) => (
              <FilterChip key={option.key} selected={sort === option.key} label={option.label} onPress={() => setSort(option.key)} />
            ))}
          </View>
          <Pressable onPress={() => setIncludeCancelled((value) => !value)} style={styles.cancelToggle}>
            <View style={[styles.checkbox, { backgroundColor: includeCancelled ? colors.primary : colors.card, borderColor: includeCancelled ? colors.primary : colors.border }]}>
              {includeCancelled && <Feather name="check" size={12} color={colors.primaryForeground} />}
            </View>
            <Text style={[styles.fieldTitle, { color: colors.foreground }]}>تضمين الفواتير الملغاة</Text>
          </Pressable>
        </Card>

        <View style={styles.resultsHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>النتائج ({filtered.length})</Text>
          <Pressable onPress={() => void shareCsv()} style={styles.exportButton}>
            <Feather name="share-2" size={15} color={colors.primary} />
            <Text style={[styles.exportText, { color: colors.primary }]}>مشاركة CSV</Text>
          </Pressable>
        </View>
        {filtered.length === 0 ? (
          <Card style={styles.empty}><Text style={[styles.help, { color: colors.mutedForeground }]}>لا توجد فواتير مطابقة لهذه الشروط.</Text></Card>
        ) : (
          filtered.map((invoice) => {
            const currency = invoiceCurrency(invoice);
            const paid = getInvoicePaidAmount(invoice.id);
            const rejected = getInvoiceRejectedAmount(invoice.id);
            return (
              <Pressable key={invoice.id} onPress={() => router.push(`/invoice/${invoice.id}` as any)}>
                <Card style={styles.invoiceCard}>
                  <View style={styles.invoiceHeader}>
                    <View>
                      <Text style={[styles.net, { color: colors.primary }]}>{formatMoney(invoice.netAmount, currency)}</Text>
                      <Text style={[styles.meta, { color: colors.mutedForeground }]}>المتبقي {formatMoney(Math.max(0, invoice.netAmount - paid - rejected), currency)}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.subscriber, { color: colors.foreground }]}>{invoice.subscriberName}</Text>
                      <Text style={[styles.meta, { color: colors.mutedForeground }]}>{invoice.invoiceNumber} · {invoice.date}</Text>
                      <Text style={[styles.meta, { color: colors.mutedForeground }]}>{invoice.insuranceCompanyName} · {invoice.serviceDepartmentName}</Text>
                    </View>
                    <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
                  </View>
                  <View style={[styles.invoiceFooter, { borderTopColor: colors.border }]}>
                    <Text style={[styles.meta, { color: colors.mutedForeground }]}>تحمل {formatMoney(invoice.coinsuranceAmount, currency)} · خصم {formatMoney(invoice.discountAmount, currency)}</Text>
                    <Text style={[styles.meta, { color: invoice.status === "cancelled" ? colors.destructive : colors.mutedForeground }]}>{invoice.status === "cancelled" ? "ملغاة" : invoice.status === "paid" ? "مدفوعة" : invoice.status === "partial" ? "جزئية" : "معلقة"}</Text>
                  </View>
                </Card>
              </Pressable>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}

function FilterChip({
  selected,
  label,
  onPress,
}: {
  selected: boolean;
  label: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={[styles.chip, { backgroundColor: selected ? colors.primary : colors.card, borderColor: selected ? colors.primary : colors.border }]}
    >
      <Text style={[styles.chipText, { color: selected ? colors.primaryForeground : colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 12 },
  card: { gap: 10 },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold", textAlign: "right" },
  help: { fontSize: 11, lineHeight: 18, fontFamily: "Inter_400Regular", textAlign: "right" },
  fieldTitle: { fontSize: 12, fontFamily: "Inter_600SemiBold", textAlign: "right" },
  chips: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 },
  chip: { borderWidth: 1, borderRadius: 100, paddingHorizontal: 11, paddingVertical: 7 },
  chipText: { fontSize: 11, fontFamily: "Inter_500Medium" },
  cancelToggle: { flexDirection: "row-reverse", alignItems: "center", gap: 8, paddingTop: 4 },
  checkbox: { width: 20, height: 20, borderRadius: 6, borderWidth: 1.5, alignItems: "center", justifyContent: "center" },
  resultsHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  exportButton: { flexDirection: "row-reverse", alignItems: "center", gap: 6 },
  exportText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  empty: { alignItems: "center", padding: 22 },
  invoiceCard: { gap: 9 },
  invoiceHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  subscriber: { textAlign: "right", fontSize: 13, fontFamily: "Inter_700Bold" },
  net: { fontSize: 13, fontFamily: "Inter_700Bold" },
  meta: { fontSize: 10, lineHeight: 16, textAlign: "right", fontFamily: "Inter_400Regular" },
  invoiceFooter: { borderTopWidth: 1, paddingTop: 7, flexDirection: "row-reverse", justifyContent: "space-between", gap: 8 },
});

