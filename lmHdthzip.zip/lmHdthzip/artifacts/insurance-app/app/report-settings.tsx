import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

export default function ReportSettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { reportSettings, updateReportSettings } = useApp();
  const [cadence, setCadence] = useState(reportSettings.cadence);
  const [customCycleDays, setCustomCycleDays] = useState(String(reportSettings.customCycleDays));
  const [splitDepartments, setSplitDepartments] = useState(reportSettings.splitDepartments);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  async function save() {
    const days = Number(customCycleDays);
    if (cadence === "custom" && (!Number.isInteger(days) || days < 1 || days > 365)) {
      setMessage("أدخل مدة صحيحة من يوم إلى 365 يومًا.");
      return;
    }
    setSaving(true);
    try {
      await updateReportSettings({
        cadence,
        customCycleDays: cadence === "custom" ? days : reportSettings.customCycleDays,
        splitDepartments,
      });
      setMessage("تم حفظ إعدادات التقارير على هذا الجهاز.");
    } catch {
      setMessage("تعذر حفظ إعدادات التقارير.");
    } finally {
      setSaving(false);
    }
  }

  const options = [
    { value: "monthly" as const, title: "شهريًا", description: "ابدأ كل تقرير من أول يوم في الشهر." },
    { value: "weekly" as const, title: "أسبوعيًا", description: "جهّز تقريرًا للفواتير خلال آخر 7 أيام." },
    { value: "custom" as const, title: "مدة أخرى", description: "حدد عدد الأيام ثم راجع تاريخ البداية والنهاية قبل الإغلاق." },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} accessibilityLabel="رجوع">
          <Feather name="arrow-right" size={23} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>إعدادات التقارير</Text>
        <View style={{ width: 23 }} />
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
      >
        <Card style={styles.card}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>دورية التقرير</Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]}>
            هذه الدورية تقترح نطاق المعاينة فقط؛ تاريخ الإغلاق النهائي يبقى ضمن مراجعتك اليدوية.
          </Text>
          {options.map((option) => {
            const selected = cadence === option.value;
            return (
              <Pressable
                key={option.value}
                accessibilityRole="radio"
                accessibilityState={{ selected }}
                onPress={() => { setCadence(option.value); setMessage(""); }}
                style={[
                  styles.option,
                  { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? colors.secondary : colors.card },
                ]}
              >
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={[styles.optionTitle, { color: colors.foreground }]}>{option.title}</Text>
                  <Text style={[styles.description, { color: colors.mutedForeground }]}>{option.description}</Text>
                </View>
                <Feather name={selected ? "check-circle" : "circle"} size={19} color={selected ? colors.primary : colors.mutedForeground} />
              </Pressable>
            );
          })}
          {cadence === "custom" && (
            <Input
              label="عدد أيام الدورة"
              value={customCycleDays}
              onChangeText={(value) => { setCustomCycleDays(value); setMessage(""); }}
              keyboardType="number-pad"
              placeholder="30"
            />
          )}
        </Card>

        <Card style={styles.card}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>تقسيم المطالبات</Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]}>
            هل تريد تقريرًا مستقلًا لكل قسم داخل كل شركة تأمين؟
          </Text>
          {[
            { selected: true, title: "تقسيم حسب الشركة والقسم", description: "شركة × قسم × عملة؛ مناسب عندما تطلب الشركة تقريرًا منفصلًا لكل قسم." },
            { selected: false, title: "الأقسام مدمجة لكل شركة", description: "تقرير واحد لكل شركة تأمين، وتظهر أسماء الأقسام في صفوف الفواتير." },
          ].map((option) => {
            const selected = splitDepartments === option.selected;
            return (
              <Pressable
                key={String(option.selected)}
                accessibilityRole="radio"
                accessibilityState={{ selected }}
                onPress={() => { setSplitDepartments(option.selected); setMessage(""); }}
                style={[
                  styles.option,
                  { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? colors.secondary : colors.card },
                ]}
              >
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={[styles.optionTitle, { color: colors.foreground }]}>{option.title}</Text>
                  <Text style={[styles.description, { color: colors.mutedForeground }]}>{option.description}</Text>
                </View>
                <Feather name={selected ? "check-circle" : "circle"} size={19} color={selected ? colors.primary : colors.mutedForeground} />
              </Pressable>
            );
          })}
        </Card>

        <View style={[styles.notice, { backgroundColor: colors.warning + "12", borderColor: colors.warning + "35" }]}>
          <Feather name="alert-triangle" size={16} color={colors.warning} />
          <Text style={[styles.noticeText, { color: colors.foreground }]}>
            لا يُغلق التقرير تلقائيًا بعد المشاركة؛ المشاركة لا تؤكد وصوله للشركة. بعد الإغلاق لا يمكن نقل الفاتورة إلى دورة جديدة حتى لا تُحتسب مرتين.
          </Text>
        </View>
        {message ? (
          <Text style={[styles.message, { color: message.startsWith("تم") ? colors.success : colors.destructive }]}>
            {message}
          </Text>
        ) : null}
        <Button title="حفظ الإعدادات" onPress={() => void save()} loading={saving} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 14 },
  card: { gap: 10 },
  sectionTitle: { fontSize: 15, textAlign: "right", fontFamily: "Inter_700Bold" },
  description: { fontSize: 11, lineHeight: 17, textAlign: "right", fontFamily: "Inter_400Regular" },
  option: { flexDirection: "row-reverse", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 11, padding: 11 },
  optionTitle: { textAlign: "right", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  notice: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 8, borderWidth: 1, borderRadius: 11, padding: 11 },
  noticeText: { flex: 1, textAlign: "right", fontSize: 11, lineHeight: 18, fontFamily: "Inter_400Regular" },
  message: { fontSize: 12, textAlign: "right", fontFamily: "Inter_500Medium" },
});

