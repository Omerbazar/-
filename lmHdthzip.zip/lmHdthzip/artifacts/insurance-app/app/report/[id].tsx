import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { Share } from "react-native";
import React, { useMemo, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatMoney, invoiceCurrency, reportFinancials } from "@/utils/accounting";

export default function PeriodicReportDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const {
    reports,
    invoices,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
    addReportSettlement,
    rejectReportInvoice,
  } = useApp();
  const report = reports.find((item) => item.id === id);
  const [showSettlement, setShowSettlement] = useState(false);
  const [paymentNotes, setPaymentNotes] = useState("");
  const [paymentError, setPaymentError] = useState("");
  const [allocationAmounts, setAllocationAmounts] = useState<Record<string, string>>({});
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [rejectionError, setRejectionError] = useState("");
  const [busy, setBusy] = useState(false);

  const items = useMemo(
    () =>
      report
        ? report.invoiceIds
            .map((invoiceId) => invoices.find((invoice) => invoice.id === invoiceId))
            .filter((invoice) => !!invoice)
            .sort((a, b) => a.date.localeCompare(b.date) || a.invoiceNumber.localeCompare(b.invoiceNumber))
        : [],
    [report, invoices]
  );

  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;
  if (!report) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={[styles.notFound, { color: colors.foreground }]}>التقرير غير موجود.</Text>
      </View>
    );
  }

  const activeReport = report;
  const financials = reportFinancials(activeReport, invoices);
  const invoiceOutstanding = (invoiceId: string) => {
    const invoice = invoices.find((item) => item.id === invoiceId);
    if (!invoice) return 0;
    return Math.max(
      0,
      invoice.netAmount -
        getInvoicePaidAmount(invoiceId) -
        getInvoiceRejectedAmount(invoiceId)
    );
  };
  const paymentAllocations = Object.entries(allocationAmounts)
    .map(([invoiceId, value]) => ({ invoiceId, amount: Number(value) }))
    .filter((allocation) => Number.isFinite(allocation.amount) && allocation.amount > 0);
  const paymentTotal = paymentAllocations.reduce(
    (sum, allocation) => sum + allocation.amount,
    0
  );

  function openSettlementForm() {
    setAllocationAmounts({});
    setPaymentError("");
    setShowSettlement(true);
  }

  function updateAllocationAmount(invoiceId: string, value: string) {
    setAllocationAmounts((current) => ({ ...current, [invoiceId]: value }));
    setPaymentError("");
  }

  async function shareReport() {
    const fields = ["رقم الفاتورة", "التاريخ", "المشترك", "جهة العمل", "القسم", "العملة", "الإجمالي", "نسبة التحمل", "مبلغ التحمل", "نسبة الخصم", "مبلغ الخصم", "الصافي", "المحصّل", "المرفوض", "المتبقي", "كود الموافقة", "ملاحظات"];
    const escape = (value: unknown) => `"${String(value ?? "").replaceAll('"', '""')}"`;
    const lines = items.map((invoice) => {
      const currency = invoiceCurrency(invoice);
      const paid = getInvoicePaidAmount(invoice.id);
      const rejected = activeReport.rejections
        .filter((item) => item.invoiceId === invoice.id)
        .reduce((sum, item) => sum + item.amount, 0);
      return [
        invoice.invoiceNumber,
        invoice.date,
        invoice.subscriberName,
        invoice.employerName,
        invoice.serviceDepartmentName,
        currency,
        invoice.totalAmount,
        invoice.coinsurancePercent,
        invoice.coinsuranceAmount,
        invoice.discountPercent,
        invoice.discountAmount,
        invoice.netAmount,
        paid,
        rejected,
        Math.max(0, invoice.netAmount - paid - rejected),
        invoice.exceptionCode,
        invoice.notes,
      ].map(escape).join(",");
    });
    await Share.share({
      title: `تقرير ${activeReport.companyName}`,
      message: [
        `# ${activeReport.companyName}${activeReport.departmentName ? ` - ${activeReport.departmentName}` : ""}`,
        `الفترة: ${activeReport.dateFrom} – ${activeReport.dateTo}`,
        `العملة: ${activeReport.currency}`,
        fields.map(escape).join(","),
        ...lines,
        `,,,,,,,,,,,,,"${financials.total}","${financials.paid}","${financials.rejected}","${financials.outstanding}"`,
      ].join("\n"),
    });
  }

  async function saveSettlement() {
    setPaymentError("");
    const invalid = Object.entries(allocationAmounts).some(([invoiceId, value]) => {
      if (!value.trim()) return false;
      const amount = Number(value);
      return !Number.isFinite(amount) || amount < 0 ||
        amount > invoiceOutstanding(invoiceId) + 0.005;
    });
    if (invalid) {
      setPaymentError("راجع المبالغ المدخلة؛ لا يمكن أن تتجاوز دفعة أي فاتورة متبقيها.");
      return;
    }
    if (!paymentAllocations.length) {
      setPaymentError("أدخل مبلغًا لفاتورة واحدة على الأقل.");
      return;
    }
    setBusy(true);
    try {
      await addReportSettlement(
        activeReport.id,
        paymentAllocations,
        paymentNotes
      );
      setPaymentNotes("");
      setAllocationAmounts({});
      setShowSettlement(false);
    } catch (error) {
      setPaymentError(error instanceof Error ? error.message : "تعذر تسجيل الدفعة.");
    } finally {
      setBusy(false);
    }
  }

  async function saveRejection(invoiceId: string) {
    setRejectionError("");
    setBusy(true);
    try {
      await rejectReportInvoice(activeReport.id, invoiceId, rejectionReason);
      setRejectingId(null);
      setRejectionReason("");
    } catch (error) {
      setRejectionError(error instanceof Error ? error.message : "تعذر حفظ الرفض.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} accessibilityLabel="رجوع">
          <Feather name="arrow-right" size={23} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>تفاصيل التقرير</Text>
        <Pressable onPress={() => void shareReport()} accessibilityLabel="مشاركة التقرير">
          <Feather name="share-2" size={19} color={colors.primary} />
        </Pressable>
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.card}>
          <Text style={[styles.companyTitle, { color: colors.foreground }]}>{report.companyName}</Text>
          {report.departmentName ? <Text style={[styles.meta, { color: colors.mutedForeground }]}>{report.departmentName}</Text> : null}
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>الفترة: {report.dateFrom} – {report.dateTo} · أُغلق في {report.closedAt.slice(0, 10)}</Text>
          <View style={[styles.moneyRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.money, { color: colors.primary }]}>{formatMoney(financials.total, report.currency)}</Text>
            <Text style={[styles.meta, { color: colors.foreground }]}>إجمالي المطالبة</Text>
          </View>
          <View style={[styles.moneyRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.money, { color: colors.success }]}>{formatMoney(financials.paid, report.currency)}</Text>
            <Text style={[styles.meta, { color: colors.foreground }]}>المحصّل</Text>
          </View>
          <View style={[styles.moneyRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.money, { color: colors.destructive }]}>{formatMoney(financials.rejected, report.currency)}</Text>
            <Text style={[styles.meta, { color: colors.foreground }]}>المستبعد بالرفض</Text>
          </View>
          <View style={styles.moneyRow}>
            <Text style={[styles.money, { color: colors.warning }]}>{formatMoney(financials.outstanding, report.currency)}</Text>
            <Text style={[styles.meta, { color: colors.foreground }]}>المتبقي للتحصيل</Text>
          </View>
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>
            {items.length} فاتورة · العملة {report.currency}. التقارير الخاصة لا تغيّر هذه المطالبة.
          </Text>
          <Pressable onPress={() => void shareReport()} style={[styles.shareButton, { borderColor: colors.border }]}>
            <Feather name="share-2" size={16} color={colors.primary} />
            <Text style={[styles.shareText, { color: colors.primary }]}>مشاركة / تصدير CSV</Text>
          </Pressable>
        </Card>

        {financials.outstanding > 0.005 && (
          showSettlement ? (
            <Card style={styles.card}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>تسجيل دفعة من الشركة</Text>
              <Text style={[styles.help, { color: colors.mutedForeground }]}>أدخل المبلغ المحوّل لكل فاتورة كما ورد في إشعار الشركة. لا يوزّع النظام المبلغ تلقائيًا؛ الفاتورة التي تتركها بلا مبلغ لن يتغير رصيدها.</Text>
              <View style={styles.allocationList}>
                {items
                  .filter((invoice) => invoiceOutstanding(invoice.id) > 0.005)
                  .map((invoice) => {
                    return (
                      <View
                        key={invoice.id}
                        style={[
                          styles.allocationOption,
                          { borderColor: colors.border, backgroundColor: colors.card },
                        ]}
                      >
                        <View style={styles.allocationHeader}>
                          <Text style={[styles.allocationName, { color: colors.foreground }]}>
                            {invoice.invoiceNumber} · {invoice.subscriberName}
                          </Text>
                          <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                            المتبقي {formatMoney(invoiceOutstanding(invoice.id), report.currency)}
                          </Text>
                        </View>
                        <Input
                          label={`المبلغ المدفوع لهذه الفاتورة (${report.currency})`}
                          value={allocationAmounts[invoice.id] ?? ""}
                          onChangeText={(value) => updateAllocationAmount(invoice.id, value)}
                          keyboardType="decimal-pad"
                          placeholder="0"
                        />
                      </View>
                    );
                  })}
              </View>
              <View style={[styles.moneyRow, { borderBottomColor: colors.border }]}>
                <Text style={[styles.money, { color: colors.primary }]}>{formatMoney(paymentTotal, report.currency)}</Text>
                <Text style={[styles.meta, { color: colors.foreground }]}>إجمالي الدفعة المدخلة</Text>
              </View>
              <Input label="ملاحظات الدفع" value={paymentNotes} onChangeText={setPaymentNotes} placeholder="مرجع التحويل أو ملاحظة اختيارية" multiline />
              {paymentError ? <Text style={[styles.error, { color: colors.destructive }]}>{paymentError}</Text> : null}
              <View style={styles.actionRow}>
                <Button title="إلغاء" onPress={() => { setShowSettlement(false); setPaymentError(""); setAllocationAmounts({}); }} variant="ghost" style={{ flex: 1 }} />
                <Button title="حفظ الدفعة" onPress={() => void saveSettlement()} loading={busy} style={{ flex: 1 }} />
              </View>
            </Card>
          ) : (
            <Button title="تسجيل دفعة من شركة التأمين" icon={<Feather name="credit-card" size={16} color={colors.primaryForeground} />} onPress={openSettlementForm} />
          )
        )}

        {report.settlements.length > 0 && (
          <Card style={styles.card}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>سجل دفعات التقرير</Text>
            {report.settlements.map((settlement) => (
              <View key={settlement.id} style={[styles.settlementRow, { borderBottomColor: colors.border }]}>
                <Text style={[styles.money, { color: colors.success }]}>{formatMoney(settlement.amount, report.currency)}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.meta, { color: colors.foreground }]}>{settlement.date} · وُزعت على {settlement.allocations.length} فاتورة</Text>
                  {settlement.notes ? <Text style={[styles.meta, { color: colors.mutedForeground }]}>{settlement.notes}</Text> : null}
                </View>
              </View>
            ))}
          </Card>
        )}

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>الفواتير ({items.length})</Text>
        {items.map((invoice) => {
          const paid = getInvoicePaidAmount(invoice.id);
          const rejected = report.rejections
            .filter((item) => item.invoiceId === invoice.id)
            .reduce((sum, item) => sum + item.amount, 0);
          const due = Math.max(0, invoice.netAmount - paid - rejected);
          return (
            <Card key={invoice.id} style={styles.invoiceCard}>
              <View style={styles.invoiceTop}>
                <Text style={[styles.money, { color: due > 0.005 ? colors.warning : colors.success }]}>{formatMoney(due, report.currency)}</Text>
                <Pressable onPress={() => router.push(`/invoice/${invoice.id}` as any)} style={{ flex: 1 }}>
                  <Text style={[styles.invoiceName, { color: colors.primary }]}>{invoice.invoiceNumber} · {invoice.subscriberName}</Text>
                  <Text style={[styles.meta, { color: colors.mutedForeground }]}>{invoice.date} · {invoice.serviceDepartmentName}</Text>
                </Pressable>
                <Pressable onPress={() => router.push(`/invoice/${invoice.id}` as any)} accessibilityLabel={`فتح الفاتورة ${invoice.invoiceNumber}`}>
                  <Feather name="external-link" size={16} color={colors.primary} />
                </Pressable>
              </View>
              <View style={[styles.dataGrid, { borderTopColor: colors.border }]}>
                <DataCell label="الإجمالي" value={formatMoney(invoice.totalAmount, invoiceCurrency(invoice))} />
                <DataCell label={`التحمل ${invoice.coinsurancePercent}%`} value={formatMoney(invoice.coinsuranceAmount, invoiceCurrency(invoice))} />
                <DataCell label={`الخصم ${invoice.discountPercent}%`} value={formatMoney(invoice.discountAmount, invoiceCurrency(invoice))} />
                <DataCell label="الصافي" value={formatMoney(invoice.netAmount, invoiceCurrency(invoice))} />
                <DataCell label="المحصّل" value={formatMoney(paid, invoiceCurrency(invoice))} />
                {invoice.exceptionCode ? <DataCell label="كود الموافقة" value={invoice.exceptionCode} /> : null}
              </View>
              {invoice.notes ? <Text style={[styles.meta, { color: colors.foreground }]}>ملاحظة: {invoice.notes}</Text> : null}
              {report.rejections.filter((item) => item.invoiceId === invoice.id).map((rejection) => (
                <View key={rejection.id} style={[styles.rejectionNote, { backgroundColor: colors.destructive + "10" }]}>
                  <Text style={[styles.rejectionText, { color: colors.destructive }]}>
                    مرفوض {formatMoney(rejection.amount, report.currency)} · {rejection.reason}
                  </Text>
                </View>
              ))}
              {due > 0.005 && (
                rejectingId === invoice.id ? (
                  <View style={styles.rejectForm}>
                    <Input label={`سبب الرفض والمبلغ المتبقي (${formatMoney(due, report.currency)}) *`} value={rejectionReason} onChangeText={(value) => { setRejectionReason(value); setRejectionError(""); }} placeholder="اكتب سبب رفض شركة التأمين" multiline />
                    {rejectionError ? <Text style={[styles.error, { color: colors.destructive }]}>{rejectionError}</Text> : null}
                    <View style={styles.actionRow}>
                      <Button title="إلغاء" onPress={() => { setRejectingId(null); setRejectionReason(""); setRejectionError(""); }} variant="ghost" style={{ flex: 1 }} />
                      <Button title="حفظ الرفض" onPress={() => void saveRejection(invoice.id)} loading={busy} variant="destructive" style={{ flex: 1 }} />
                    </View>
                  </View>
                ) : (
                  <Pressable onPress={() => setRejectingId(invoice.id)} style={[styles.rejectButton, { borderColor: colors.destructive + "40" }]}>
                    <Feather name="alert-circle" size={15} color={colors.destructive} />
                    <Text style={[styles.rejectLabel, { color: colors.destructive }]}>تسجيل رفض المتبقي</Text>
                  </Pressable>
                )
              )}
            </Card>
          );
        })}
      </ScrollView>
    </View>
  );
}

function DataCell({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.dataCell}>
      <Text style={[styles.dataValue, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 12 },
  notFound: { padding: 20, textAlign: "right", fontFamily: "Inter_500Medium" },
  card: { gap: 10 },
  companyTitle: { textAlign: "right", fontSize: 17, fontFamily: "Inter_700Bold" },
  sectionTitle: { textAlign: "right", fontSize: 15, fontFamily: "Inter_700Bold" },
  meta: { textAlign: "right", fontSize: 10, lineHeight: 16, fontFamily: "Inter_400Regular" },
  help: { textAlign: "right", fontSize: 11, lineHeight: 18, fontFamily: "Inter_400Regular" },
  moneyRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, paddingVertical: 7 },
  money: { fontSize: 13, fontFamily: "Inter_700Bold" },
  shareButton: { flexDirection: "row-reverse", justifyContent: "center", alignItems: "center", gap: 7, padding: 10, borderWidth: 1, borderRadius: 10 },
  shareText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  actionRow: { flexDirection: "row", gap: 9 },
  error: { fontSize: 12, textAlign: "right", fontFamily: "Inter_500Medium" },
  settlementRow: { flexDirection: "row-reverse", gap: 10, alignItems: "center", paddingVertical: 8, borderBottomWidth: 1 },
  invoiceCard: { gap: 9 },
  invoiceTop: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  invoiceName: { textAlign: "right", fontSize: 12, fontFamily: "Inter_700Bold" },
  dataGrid: { flexDirection: "row-reverse", flexWrap: "wrap", borderTopWidth: 1, paddingTop: 8, gap: 8 },
  dataCell: { width: "47%", gap: 3 },
  dataValue: { textAlign: "right", fontSize: 11, fontFamily: "Inter_600SemiBold" },
  dataLabel: { textAlign: "right", fontSize: 9, fontFamily: "Inter_400Regular" },
  rejectionNote: { borderRadius: 8, padding: 8 },
  rejectionText: { textAlign: "right", fontSize: 11, lineHeight: 17, fontFamily: "Inter_500Medium" },
  rejectForm: { gap: 8, paddingTop: 5 },
  allocationList: { gap: 7 },
  allocationOption: { gap: 8, borderWidth: 1, borderRadius: 10, padding: 10 },
  allocationHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", gap: 8 },
  allocationName: { textAlign: "right", fontSize: 11, fontFamily: "Inter_600SemiBold" },
  rejectButton: { flexDirection: "row-reverse", justifyContent: "center", alignItems: "center", gap: 7, borderWidth: 1, borderRadius: 10, padding: 9 },
  rejectLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
});

