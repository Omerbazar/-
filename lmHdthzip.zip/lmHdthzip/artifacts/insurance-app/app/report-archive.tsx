import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { useApp, PeriodicReport } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatMoney, reportFinancials } from "@/utils/accounting";

type ArchiveTab = "closed" | "paid" | "rejected";

export default function ReportArchiveScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { reports, invoices } = useApp();
  const [tab, setTab] = useState<ArchiveTab>("closed");
  const tabs: { key: ArchiveTab; label: string }[] = [
    { key: "closed", label: "مغلقة / غير مدفوعة" },
    { key: "paid", label: "مدفوعة" },
    { key: "rejected", label: "مرفوضة" },
  ];

  const visibleReports = useMemo(() => {
    return [...reports]
      .filter((report) => {
        const finances = reportFinancials(report, invoices);
        if (tab === "closed") return finances.outstanding > 0.005;
        if (tab === "paid") return finances.outstanding <= 0.005 && finances.paid > 0.005;
        return report.rejections.length > 0;
      })
      .sort((a, b) => b.closedAt.localeCompare(a.closedAt));
  }, [reports, invoices, tab]);

  const rejectedRows = useMemo(
    () =>
      reports
        .flatMap((report) =>
          report.rejections.map((rejection) => ({
            report,
            rejection,
            invoice: invoices.find((item) => item.id === rejection.invoiceId),
          }))
        )
        .sort((a, b) => b.rejection.date.localeCompare(a.rejection.date)),
    [reports, invoices]
  );

  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} accessibilityLabel="رجوع">
          <Feather name="arrow-right" size={23} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>أرشيف التقارير</Text>
        <View style={{ width: 23 }} />
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.tabBar, { backgroundColor: colors.muted }]}>
          {tabs.map((item) => (
            <Pressable
              key={item.key}
              onPress={() => setTab(item.key)}
              style={[styles.tab, { backgroundColor: tab === item.key ? colors.card : "transparent", borderColor: tab === item.key ? colors.border : "transparent" }]}
            >
              <Text style={[styles.tabText, { color: tab === item.key ? colors.foreground : colors.mutedForeground }]}>{item.label}</Text>
            </Pressable>
          ))}
        </View>
        {tab === "rejected" ? (
          rejectedRows.length === 0 ? (
            <EmptyState label="لا توجد فواتير مرفوضة في الأرشيف." />
          ) : (
            rejectedRows.map(({ report, rejection, invoice }) => (
              <Pressable key={rejection.id} onPress={() => router.push(`/report/${report.id}` as any)}>
                <Card style={styles.card}>
                  <View style={styles.row}>
                    <Text style={[styles.amount, { color: colors.destructive }]}>{formatMoney(rejection.amount, report.currency)}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.company, { color: colors.foreground }]}>{invoice?.invoiceNumber ?? rejection.invoiceId}</Text>
                      <Text style={[styles.meta, { color: colors.mutedForeground }]}>{invoice?.subscriberName ?? "المشترك غير متاح"} · {rejection.date}</Text>
                    </View>
                    <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
                  </View>
                  <Text style={[styles.reason, { color: colors.foreground }]}>سبب الرفض: {rejection.reason}</Text>
                  <Text style={[styles.meta, { color: colors.mutedForeground }]}>{report.companyName} · {report.dateFrom} – {report.dateTo}</Text>
                </Card>
              </Pressable>
            ))
          )
        ) : visibleReports.length === 0 ? (
          <EmptyState label={tab === "paid" ? "لا توجد تقارير مدفوعة بعد." : "لا توجد تقارير مغلقة بمتبقي."} />
        ) : (
          visibleReports.map((report) => (
            <ReportCard key={report.id} report={report} invoices={invoices} />
          ))
        )}
      </ScrollView>
    </View>
  );
}

function ReportCard({
  report,
  invoices,
}: {
  report: PeriodicReport;
  invoices: ReturnType<typeof useApp>["invoices"];
}) {
  const colors = useColors();
  const finances = reportFinancials(report, invoices);
  const isPaid = finances.outstanding <= 0.005 && finances.paid > 0.005;
  return (
    <Pressable onPress={() => router.push(`/report/${report.id}` as any)}>
      <Card style={styles.card}>
        <View style={styles.row}>
          <Badge label={isPaid ? "مدفوع" : "مغلق · بانتظار التحصيل"} variant={isPaid ? "success" : "warning"} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.company, { color: colors.foreground }]}>{report.companyName}</Text>
            {report.departmentName ? <Text style={[styles.meta, { color: colors.mutedForeground }]}>{report.departmentName}</Text> : null}
          </View>
          <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
        </View>
        <View style={[styles.row, { justifyContent: "space-between" }]}>
          <View style={{ alignItems: "flex-start" }}>
            <Text style={[styles.amount, { color: colors.warning }]}>{formatMoney(finances.outstanding, report.currency)}</Text>
            <Text style={[styles.meta, { color: colors.mutedForeground }]}>متبقي</Text>
          </View>
          <View style={{ alignItems: "flex-end" }}>
            <Text style={[styles.amount, { color: colors.primary }]}>{formatMoney(report.totalAmount, report.currency)}</Text>
            <Text style={[styles.meta, { color: colors.mutedForeground }]}>{report.invoiceIds.length} فاتورة · {report.currency}</Text>
          </View>
        </View>
        <Text style={[styles.meta, { color: colors.mutedForeground, textAlign: "right" }]}>
          {report.dateFrom} – {report.dateTo} · إغلاق {report.closedAt.slice(0, 10)}
          {report.rejections.length ? ` · ${report.rejections.length} مرفوضة` : ""}
        </Text>
      </Card>
    </Pressable>
  );
}

function EmptyState({ label }: { label: string }) {
  const colors = useColors();
  return (
    <Card style={styles.empty}>
      <Feather name="archive" size={22} color={colors.mutedForeground} />
      <Text style={[styles.meta, { color: colors.mutedForeground, textAlign: "center" }]}>{label}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 12 },
  tabBar: { flexDirection: "row-reverse", flexWrap: "wrap", borderRadius: 12, padding: 4, gap: 4 },
  tab: { flexGrow: 1, borderWidth: 1, borderRadius: 9, paddingHorizontal: 8, paddingVertical: 9, alignItems: "center" },
  tabText: { fontSize: 10, fontFamily: "Inter_500Medium", textAlign: "center" },
  card: { gap: 10 },
  row: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  company: { textAlign: "right", fontSize: 14, fontFamily: "Inter_700Bold" },
  amount: { fontSize: 14, fontFamily: "Inter_700Bold" },
  meta: { fontSize: 10, lineHeight: 16, fontFamily: "Inter_400Regular", textAlign: "right" },
  reason: { textAlign: "right", fontSize: 12, lineHeight: 18, fontFamily: "Inter_500Medium" },
  empty: { alignItems: "center", gap: 8, padding: 22 },
});

