import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp, generateId, Invoice } from "@/context/AppContext";
import { CURRENCIES, type CurrencyCode } from "@/constants/currencies";
import { currencyMark, formatMoney } from "@/utils/accounting";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export default function NewInvoiceScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { subscribers, employers, insuranceCompanies, entity, addInvoice, invoices } =
    useApp();

  const [cardCodeSearch, setCardCodeSearch] = useState("");
  const [selectedSubscriberId, setSelectedSubscriberId] = useState("");
  const [totalAmount, setTotalAmount] = useState("");
  const [invoiceCurrency, setInvoiceCurrency] = useState<CurrencyCode>(entity.baseCurrency ?? "SAR");
  const [exchangeRate, setExchangeRate] = useState("1");
  const [notes, setNotes] = useState("");
  const [selectedRateId, setSelectedRateId] = useState("");
  const [selectedDeptId, setSelectedDeptId] = useState("");
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [exceptionMode, setExceptionMode] = useState(false);
  const [exceptionCode, setExceptionCode] = useState("");
  const [exceptionNotes, setExceptionNotes] = useState("");

  const activeDepartments = entity.departments.filter(
    (department) => department.active !== false
  );
  const subscriber = subscribers.find((s) => s.id === selectedSubscriberId);
  const employer = subscriber
    ? employers.find((e) => e.id === subscriber.employerId)
    : undefined;
  const section = employer
    ? employer.sections.find((s) => s.id === subscriber?.employerSectionId)
    : undefined;
  const insuranceCompany = employer
    ? insuranceCompanies.find((c) => c.id === employer.insuranceCompanyId)
    : undefined;

  const availableRates = useMemo(() => {
    const sectionRates = section
      ? section.rates.filter((r) => r.active).map((r) => ({ ...r, source: "section" as const }))
      : [];
    const exceptionalRates = subscriber
      ? subscriber.exceptionalRates.map((r) => ({ ...r, source: "exceptional" as const, active: true }))
      : [];
    return [...sectionRates, ...exceptionalRates];
  }, [section, subscriber]);

  const selectedRate = availableRates.find((r) => r.id === selectedRateId);
  const selectedDept = activeDepartments.find((d) => d.id === selectedDeptId);

  const discount = useMemo(() => {
    if (!insuranceCompany || !selectedDeptId) return 0;
    const disc = insuranceCompany.discounts.find(
      (d) => d.departmentId === selectedDeptId
    );
    return disc ? disc.discountPercent : 0;
  }, [insuranceCompany, selectedDeptId]);

  const calculations = useMemo(() => {
    const amount = parseFloat(totalAmount) || 0;
    const coinsurancePercent = selectedRate ? selectedRate.percent : 0;
    const coinsuranceAmount = amount * (coinsurancePercent / 100);
    const discountAmount = amount * (discount / 100);
    const netAmount = amount - coinsuranceAmount - discountAmount;
    const rateToBase = invoiceCurrency === (entity.baseCurrency ?? "SAR")
      ? 1
      : parseFloat(exchangeRate);
    return {
      amount,
      coinsurancePercent,
      coinsuranceAmount,
      discountAmount,
      netAmount,
      rateToBase,
      baseTotalAmount: Number.isFinite(rateToBase) ? amount * rateToBase : undefined,
      baseCoinsuranceAmount: Number.isFinite(rateToBase) ? coinsuranceAmount * rateToBase : undefined,
      baseDiscountAmount: Number.isFinite(rateToBase) ? discountAmount * rateToBase : undefined,
      baseNetAmount: Number.isFinite(rateToBase) ? netAmount * rateToBase : undefined,
    };
  }, [totalAmount, selectedRate, discount, invoiceCurrency, exchangeRate, entity.baseCurrency]);

  const ceilingExceeded =
    selectedRate &&
    "ceiling" in selectedRate &&
    (selectedRate as any).ceiling > 0 &&
    calculations.amount > (selectedRate as any).ceiling;

  const searchResults = useMemo(() => {
    const q = cardCodeSearch.trim().toLowerCase();
    if (!q) return [];
    return subscribers
      .filter(
        (s) =>
          s.status === "active" &&
          (s.cardCode.toLowerCase().includes(q) || s.name.includes(q))
      )
      .slice(0, 5);
  }, [cardCodeSearch, subscribers]);

  function validate() {
    const e: Record<string, string> = {};
    if (!selectedSubscriberId) e.subscriber = "يجب اختيار مشترك";
    if (!totalAmount || parseFloat(totalAmount) <= 0) e.amount = "مبلغ الفاتورة مطلوب";
    if (!selectedRateId) e.rate = "يجب اختيار نسبة التحمل";
    if (!selectedDeptId) e.dept = "يجب اختيار القسم";
    if (ceilingExceeded && !exceptionMode) e.ceiling = "المبلغ تجاوز سقف الحالة";
    if (exceptionMode && !exceptionCode.trim()) e.exceptionCode = "كود الموافقة مطلوب";
    if (
      invoiceCurrency !== (entity.baseCurrency ?? "SAR") &&
      (!Number.isFinite(calculations.rateToBase) || calculations.rateToBase <= 0)
    ) e.exchangeRate = "أدخل سعر صرف صحيحًا إلى العملة الأساسية";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSave() {
    if (!validate()) return;
    if (!subscriber || !employer || !insuranceCompany || !selectedDept || !selectedRate)
      return;

    setSaving(true);
    const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`;
    const invoice: Invoice = {
      id: generateId(),
      invoiceNumber,
      subscriberId: subscriber.id,
      subscriberName: subscriber.name,
      employerId: employer.id,
      employerName: employer.name,
      insuranceCompanyId: insuranceCompany.id,
      insuranceCompanyName: insuranceCompany.name,
      serviceDepartmentId: selectedDept.id,
      serviceDepartmentName: selectedDept.name,
      totalAmount: calculations.amount,
      coinsuranceRateId: selectedRate.id,
      coinsuranceRateName: selectedRate.name,
      coinsurancePercent: calculations.coinsurancePercent,
      coinsuranceAmount: calculations.coinsuranceAmount,
      discountPercent: discount,
      discountAmount: calculations.discountAmount,
      netAmount: calculations.netAmount,
      currency: invoiceCurrency,
      exchangeRateToBase: calculations.rateToBase,
      baseTotalAmount: calculations.baseTotalAmount,
      baseCoinsuranceAmount: calculations.baseCoinsuranceAmount,
      baseDiscountAmount: calculations.baseDiscountAmount,
      baseNetAmount: calculations.baseNetAmount,
      status: "pending",
      date: new Date().toISOString().split("T")[0],
      exceptionCode,
      exceptionNotes,
      approvalRequested: exceptionMode,
      notes: notes.trim(),
      payments: [],
      paidAmount: 0,
    };

    await addInvoice(invoice);
    setSaving(false);
    router.back();
  }

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topPt + 12,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable onPress={() => router.back()}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]}>
          فاتورة جديدة
        </Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            1. البحث عن المشترك
          </Text>
          <Input
            label="كود البطاقة أو الاسم"
            value={cardCodeSearch}
            onChangeText={(t) => {
              setCardCodeSearch(t);
              setSelectedSubscriberId("");
            }}
            placeholder="ابحث بالكود أو الاسم..."
          />
          {searchResults.length > 0 && !selectedSubscriberId && (
            <View
              style={[
                styles.searchResults,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              {searchResults.map((s) => (
                <Pressable
                  key={s.id}
                  onPress={() => {
                    setSelectedSubscriberId(s.id);
                    setCardCodeSearch(s.name);
                    setSelectedRateId("");
                    if (activeDepartments.length === 1) {
                      setSelectedDeptId(activeDepartments[0].id);
                    }
                  }}
                  style={[styles.searchItem, { borderBottomColor: colors.border }]}
                >
                  <Text style={[styles.searchName, { color: colors.foreground }]}>
                    {s.name}
                  </Text>
                  <Text style={[styles.searchCode, { color: colors.mutedForeground }]}>
                    {s.cardCode}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}
          {errors.subscriber && (
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              {errors.subscriber}
            </Text>
          )}

          {subscriber && (
            <View
              style={[styles.subscriberInfo, { backgroundColor: colors.secondary }]}
            >
              {[
                { label: "جهة العمل", value: employer?.name },
                { label: "القسم", value: section?.name },
                { label: "شركة التأمين", value: insuranceCompany?.name },
              ].map((row) => (
                <View key={row.label} style={styles.infoRow}>
                  <Text style={[styles.infoValue, { color: colors.foreground }]}>
                    {row.value ?? "—"}
                  </Text>
                  <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>
                    {row.label}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </Card>

        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            2. مبلغ الفاتورة والعملة
          </Text>
          <Text style={[styles.helpText, { color: colors.mutedForeground }]}>
            العملة الأساسية المحددة: {entity.baseCurrency ?? "SAR"}. كل فاتورة تحتفظ بعملتها؛ لا تُجمع العملات المختلفة في التقرير نفسه.
          </Text>
          <View style={styles.chipGroup}>
            {CURRENCIES.map((currency) => (
              <Pressable
                key={currency.code}
                accessibilityRole="radio"
                accessibilityState={{ selected: invoiceCurrency === currency.code }}
                onPress={() => {
                  setInvoiceCurrency(currency.code);
                  setExchangeRate(currency.code === (entity.baseCurrency ?? "SAR") ? "1" : "");
                }}
                style={[
                  styles.chip,
                  {
                    backgroundColor: invoiceCurrency === currency.code ? colors.primary : colors.card,
                    borderColor: invoiceCurrency === currency.code ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text style={{ color: invoiceCurrency === currency.code ? colors.primaryForeground : colors.foreground, fontFamily: "Inter_500Medium", fontSize: 13 }}>
                  {currency.label}
                </Text>
              </Pressable>
            ))}
          </View>
          <Input
            label={`المبلغ الإجمالي (${currencyMark(invoiceCurrency)}) *`}
            value={totalAmount}
            onChangeText={setTotalAmount}
            placeholder="0.00"
            keyboardType="numeric"
            error={errors.amount}
          />
          {invoiceCurrency !== (entity.baseCurrency ?? "SAR") && (
            <Input
              label={`قيمة 1 ${currencyMark(invoiceCurrency)} بالعملة الأساسية (${currencyMark(entity.baseCurrency ?? "SAR")}) *`}
              value={exchangeRate}
              onChangeText={setExchangeRate}
              placeholder="أدخل سعر الصرف يدويًا"
              keyboardType="decimal-pad"
              error={errors.exchangeRate}
            />
          )}
          <Input
            label="ملاحظات الفاتورة"
            value={notes}
            onChangeText={setNotes}
            placeholder="ملاحظة اختيارية"
            multiline
          />
        </Card>

        {availableRates.length > 0 && (
          <Card style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              3. نسبة التحمل *
            </Text>
            {errors.rate && (
              <Text style={[styles.errorText, { color: colors.destructive }]}>
                {errors.rate}
              </Text>
            )}
            <View style={styles.chipGroup}>
              {availableRates.map((r) => (
                <Pressable
                  key={r.id}
                  onPress={() => setSelectedRateId(r.id)}
                  style={[
                    styles.rateChip,
                    {
                      backgroundColor:
                        selectedRateId === r.id
                          ? colors.primary
                          : colors.card,
                      borderColor:
                        selectedRateId === r.id
                          ? colors.primary
                          : colors.border,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.rateChipPercent,
                      {
                        color:
                          selectedRateId === r.id
                            ? colors.primaryForeground
                            : colors.primary,
                      },
                    ]}
                  >
                    {r.percent}%
                  </Text>
                  <Text
                    style={[
                      styles.rateChipName,
                      {
                        color:
                          selectedRateId === r.id
                            ? colors.primaryForeground
                            : colors.foreground,
                      },
                    ]}
                  >
                    {r.name}
                  </Text>
                </Pressable>
              ))}
            </View>
            {ceilingExceeded && (
              <View
                style={[
                  styles.warningBox,
                  { backgroundColor: colors.warning + "18", borderColor: colors.warning + "40" },
                ]}
              >
                <Feather name="alert-triangle" size={16} color={colors.warning} />
                <Text style={[styles.warningText, { color: colors.warning }]}>
                  المبلغ تجاوز سقف الحالة ({formatMoney((selectedRate as any).ceiling, invoiceCurrency)})
                </Text>
              </View>
            )}
          </Card>
        )}

        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            4. قسم الخدمة *
          </Text>
          {errors.dept && (
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              {errors.dept}
            </Text>
          )}
          <View style={styles.chipGroup}>
            {activeDepartments.map((d) => (
              <Pressable
                key={d.id}
                onPress={() => setSelectedDeptId(d.id)}
                style={[
                  styles.chip,
                  {
                    backgroundColor:
                      selectedDeptId === d.id ? colors.accent : colors.card,
                    borderColor:
                      selectedDeptId === d.id ? colors.accent : colors.border,
                  },
                ]}
              >
                <Text
                  style={{
                    color:
                      selectedDeptId === d.id
                        ? colors.primaryForeground
                        : colors.foreground,
                    fontFamily: "Inter_500Medium",
                    fontSize: 13,
                  }}
                >
                  {d.name}
                </Text>
              </Pressable>
            ))}
            {activeDepartments.length === 0 && (
              <Text style={[styles.errorText, { color: colors.mutedForeground }]}>
                لا توجد أقسام نشطة. أضف قسمًا من إعدادات المنشأة أولًا.
              </Text>
            )}
          </View>
          {discount > 0 && (
            <View
              style={[
                styles.discountBox,
                { backgroundColor: colors.success + "15", borderColor: colors.success + "30" },
              ]}
            >
              <Feather name="tag" size={14} color={colors.success} />
              <Text style={[styles.discountText, { color: colors.success }]}>
                خصم شركة التأمين: {discount}%
              </Text>
            </View>
          )}
        </Card>

        {calculations.amount > 0 && selectedRateId && selectedDeptId && (
          <Card style={[styles.section, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              ملخص الحساب
            </Text>
            {[
              { label: "مبلغ الفاتورة", value: formatMoney(calculations.amount, invoiceCurrency), color: colors.foreground },
              { label: `نسبة التحمل (${calculations.coinsurancePercent}%)`, value: `- ${formatMoney(calculations.coinsuranceAmount, invoiceCurrency)}`, color: colors.warning },
              { label: `الخصم (${discount}%)`, value: `- ${formatMoney(calculations.discountAmount, invoiceCurrency)}`, color: colors.accent },
            ].map((row) => (
              <View key={row.label} style={[styles.calcRow, { borderBottomColor: colors.border }]}>
                <Text style={[styles.calcValue, { color: row.color }]}>{row.value} {currencyMark(invoiceCurrency)}</Text>
                <Text style={[styles.calcLabel, { color: colors.mutedForeground }]}>{row.label}</Text>
              </View>
            ))}
            <View style={styles.calcRow}>
              <Text style={[styles.calcTotal, { color: colors.primary }]}>
                {formatMoney(calculations.netAmount, invoiceCurrency)}
              </Text>
              <Text style={[styles.calcTotalLabel, { color: colors.foreground }]}>
                الصافي النهائي
              </Text>
            </View>
          </Card>
        )}

        <Card style={styles.section}>
          <Pressable
            onPress={() => setExceptionMode(!exceptionMode)}
            style={styles.exceptionToggle}
          >
            <View
              style={[
                styles.checkbox,
                {
                  backgroundColor: exceptionMode ? colors.primary : colors.card,
                  borderColor: exceptionMode ? colors.primary : colors.border,
                },
              ]}
            >
              {exceptionMode && <Feather name="check" size={12} color={colors.primaryForeground} />}
            </View>
            <Text style={[styles.exceptionLabel, { color: colors.foreground }]}>
              إضافة كود موافقة لهذه الفاتورة
            </Text>
          </Pressable>
          {ceilingExceeded && !exceptionMode && (
            <Text style={[styles.errorText, { color: colors.warning }]}>
              يلزم تفعيل كود الموافقة لتجاوز سقف الحالة.
            </Text>
          )}
          {exceptionMode && (
            <>
              <Input
                label="كود الموافقة *"
                value={exceptionCode}
                onChangeText={setExceptionCode}
                placeholder="أدخل كود الموافقة"
                error={errors.exceptionCode}
              />
              <Input
                label="ملاحظات الموافقة"
                value={exceptionNotes}
                onChangeText={setExceptionNotes}
                placeholder="اختياري"
                multiline
              />
            </>
          )}
        </Card>

        {errors.ceiling && !exceptionMode && (
          <Text style={[styles.errorText, { color: colors.destructive, textAlign: "center" }]}>
            {errors.ceiling}
          </Text>
        )}

        <Button
          title="حفظ الفاتورة"
          onPress={handleSave}
          loading={saving}
          disabled={!!ceilingExceeded && !exceptionMode}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  title: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 16 },
  section: { gap: 12 },
  sectionTitle: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    marginBottom: 4,
  },
  helpText: { fontSize: 12, lineHeight: 18, textAlign: "right" },
  searchResults: {
    borderRadius: 10,
    borderWidth: 1,
    overflow: "hidden",
  },
  searchItem: {
    padding: 12,
    borderBottomWidth: 1,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
  },
  searchName: { fontSize: 14, fontFamily: "Inter_500Medium" },
  searchCode: { fontSize: 13, fontFamily: "Inter_400Regular" },
  subscriberInfo: { borderRadius: 10, padding: 12, gap: 6 },
  infoRow: { flexDirection: "row-reverse", justifyContent: "space-between" },
  infoLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  infoValue: { fontSize: 13, fontFamily: "Inter_500Medium" },
  chipGroup: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 100,
    borderWidth: 1,
  },
  rateChip: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    minWidth: 100,
  },
  rateChipPercent: { fontSize: 20, fontFamily: "Inter_700Bold" },
  rateChipName: { fontSize: 11, fontFamily: "Inter_400Regular" },
  calcRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
  },
  calcLabel: { fontSize: 13, fontFamily: "Inter_400Regular" },
  calcValue: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  calcTotal: { fontSize: 20, fontFamily: "Inter_700Bold" },
  calcTotalLabel: { fontSize: 15, fontFamily: "Inter_700Bold" },
  warningBox: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  warningText: { fontSize: 13, fontFamily: "Inter_500Medium", flex: 1, textAlign: "right" },
  discountBox: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  discountText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  exceptionToggle: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  exceptionLabel: { fontSize: 14, fontFamily: "Inter_500Medium" },
  errorText: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "right" },
});
