import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp, generateId, Payment } from "@/context/AppContext";
import { CURRENCIES, type CurrencyCode } from "@/constants/currencies";
import { currencyMark, formatMoney, invoiceCurrency } from "@/utils/accounting";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

export default function InvoiceDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const {
    invoices,
    cancelInvoice,
    addPayment,
    updateInvoice,
    entity,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
    isInvoiceInClosedReport,
  } = useApp();

  const invoice = invoices.find((i) => i.id === id);
  const [showPayment, setShowPayment] = useState(false);
  const [payAmount, setPayAmount] = useState("");
  const [payNotes, setPayNotes] = useState("");
  const [payCurrency, setPayCurrency] = useState<CurrencyCode>("SAR");
  const [payRate, setPayRate] = useState("");
  const [invoiceRateOverride, setInvoiceRateOverride] = useState("");
  const [paymentError, setPaymentError] = useState("");
  const [saving, setSaving] = useState(false);

  if (!invoice)
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground, padding: 20, textAlign: "right" }}>
          الفاتورة غير موجودة
        </Text>
      </View>
    );

  const currentInvoice = invoice;
  const invoiceId = invoice.id;
  const currency = invoiceCurrency(invoice);
  const paidAmount = getInvoicePaidAmount(invoiceId);
  const rejectedAmount = getInvoiceRejectedAmount(invoiceId);
  const remaining = Math.max(0, invoice.netAmount - paidAmount - rejectedAmount);
  const closedInReport = isInvoiceInClosedReport(invoiceId);

  async function handleAddPayment() {
    const sourceAmount = parseFloat(payAmount);
    if (!Number.isFinite(sourceAmount) || sourceAmount <= 0) {
      setPaymentError("أدخل مبلغًا صحيحًا.");
      return;
    }
    const baseCurrency = entity.baseCurrency ?? "SAR";
    const invoiceRate = currentInvoice.exchangeRateToBase ??
      (currency === baseCurrency ? 1 : parseFloat(invoiceRateOverride));
    const paymentRate = payCurrency === baseCurrency
      ? 1
      : payCurrency === currency && invoiceRate
        ? invoiceRate
        : parseFloat(payRate);
    if (payCurrency !== currency && (!invoiceRate || !paymentRate || paymentRate <= 0)) {
      setPaymentError("أدخل سعر صرف الدفعة والعملة إلى العملة الأساسية.");
      return;
    }
    const normalizedAmount = payCurrency === currency
      ? sourceAmount
      : (sourceAmount * paymentRate) / (invoiceRate as number);
    if (normalizedAmount > remaining + 0.005) {
      setPaymentError(`الدفعة بعد التحويل تتجاوز المتبقي ${formatMoney(remaining, currency)}.`);
      return;
    }
    setSaving(true);
    const payment: Payment = {
      id: generateId(),
      amount: normalizedAmount,
      date: new Date().toISOString().split("T")[0],
      notes: payNotes,
      currency: payCurrency,
      sourceAmount,
      exchangeRateToBase: paymentRate,
      baseAmount: paymentRate ? sourceAmount * paymentRate : undefined,
    };
    try {
      if (!currentInvoice.exchangeRateToBase && currency !== baseCurrency && invoiceRate) {
        await updateInvoice({
          ...currentInvoice,
          exchangeRateToBase: invoiceRate,
          baseTotalAmount: currentInvoice.totalAmount * invoiceRate,
          baseCoinsuranceAmount: currentInvoice.coinsuranceAmount * invoiceRate,
          baseDiscountAmount: currentInvoice.discountAmount * invoiceRate,
          baseNetAmount: currentInvoice.netAmount * invoiceRate,
        });
      }
      await addPayment(invoiceId, payment);
      setPayAmount("");
      setPayNotes("");
      setPaymentError("");
      setShowPayment(false);
    } catch (error) {
      setPaymentError(error instanceof Error ? error.message : "تعذر حفظ الدفعة.");
    } finally {
      setSaving(false);
    }
  }

  function handleCancel() {
    Alert.alert("تأكيد الإلغاء", "هل تريد إلغاء هذه الفاتورة؟", [
      { text: "لا" },
      {
        text: "نعم، إلغاء",
        style: "destructive",
        onPress: () => {
          void cancelInvoice(invoiceId)
            .then(() => router.back())
            .catch((error: unknown) =>
              Alert.alert(
                "تعذر إلغاء الفاتورة",
                error instanceof Error ? error.message : "الفاتورة مرتبطة بتقرير مغلق."
              )
            );
        },
      },
    ]);
  }

  const statusLabel =
    invoice.status === "cancelled"
      ? "ملغاة"
      : rejectedAmount > 0 && remaining <= 0.005
        ? "مرفوضة"
      : remaining <= 0.005
      ? "مدفوعة"
      : paidAmount > 0
        ? "جزئية"
        : "معلقة";

  const statusVariant =
    invoice.status === "cancelled"
      ? "error"
      : rejectedAmount > 0
        ? "warning"
      : remaining <= 0.005
      ? "success"
      : paidAmount > 0
        ? "warning"
        : "info";

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topPt + 12,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable onPress={() => router.back()}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]}>
          {invoice.invoiceNumber}
        </Text>
        <Badge label={statusLabel} variant={statusVariant} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card style={[styles.totalCard, { borderColor: colors.primary + "40" }]}>
          <View style={styles.totalRow}>
            <View style={{ alignItems: "flex-end" }}>
              <Text style={[styles.totalLabel, { color: colors.mutedForeground }]}>
                الصافي النهائي
              </Text>
              <Text style={[styles.totalAmount, { color: colors.primary }]}>
                 {formatMoney(invoice.netAmount, currency)}
              </Text>
            </View>
            <View style={{ alignItems: "flex-start" }}>
              <Text style={[styles.totalLabel, { color: colors.mutedForeground }]}>
                المتبقي
              </Text>
              <Text
                style={[
                  styles.totalAmount,
                  {
                    color: remaining > 0 ? colors.warning : colors.success,
                  },
                ]}
              >
                 {formatMoney(remaining, currency)}
              </Text>
            </View>
          </View>
          <View style={[styles.progressBg, { backgroundColor: colors.muted }]}>
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: colors.success,
                   width: `${Math.min((paidAmount / invoice.netAmount) * 100, 100)}%`,
                },
              ]}
            />
          </View>
          <Text style={[styles.progressLabel, { color: colors.mutedForeground }]}>
            مدفوع: {formatMoney(paidAmount, currency)}
          </Text>
          {rejectedAmount > 0 && (
            <Text style={[styles.progressLabel, { color: colors.destructive }]}>
              مستبعد بسبب الرفض: {formatMoney(rejectedAmount, currency)}
            </Text>
          )}
        </Card>

        <Card style={styles.card}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>
            بيانات المشترك
          </Text>
          {[
            { label: "المشترك", value: invoice.subscriberName },
            { label: "جهة العمل", value: invoice.employerName },
            { label: "شركة التأمين", value: invoice.insuranceCompanyName },
            { label: "قسم الخدمة", value: invoice.serviceDepartmentName },
          ].map((r) => (
            <View key={r.label} style={[styles.dataRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.dataValue, { color: colors.foreground }]}>{r.value}</Text>
              <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>{r.label}</Text>
            </View>
          ))}
        </Card>

        <Card style={styles.card}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>
            تفاصيل الحساب
          </Text>
          {[
             { label: "إجمالي الفاتورة", value: formatMoney(invoice.totalAmount, currency), color: colors.foreground },
             { label: `التحمل (${invoice.coinsurancePercent}%) — ${invoice.coinsuranceRateName}`, value: `- ${formatMoney(invoice.coinsuranceAmount, currency)}`, color: colors.warning },
             { label: `الخصم (${invoice.discountPercent}%)`, value: `- ${formatMoney(invoice.discountAmount, currency)}`, color: colors.accent },
             { label: "الصافي", value: formatMoney(invoice.netAmount, currency), color: colors.primary },
          ].map((r) => (
            <View key={r.label} style={[styles.dataRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.calcValue, { color: r.color }]}>{r.value}</Text>
              <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>{r.label}</Text>
            </View>
          ))}
        </Card>

        {invoice.payments.length > 0 && (
          <Card style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              سجل المدفوعات
            </Text>
            {invoice.payments.map((p) => (
              <View key={p.id} style={[styles.dataRow, { borderBottomColor: colors.border }]}>
                <Text style={[styles.dataValue, { color: colors.success }]}>
                   {formatMoney(p.sourceAmount ?? p.amount, p.currency ?? currency)}
                </Text>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={[styles.dataLabel, { color: colors.foreground }]}>{p.date}</Text>
                  {p.notes ? (
                    <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>{p.notes}</Text>
                  ) : null}
                </View>
              </View>
            ))}
          </Card>
        )}

        {invoice.exceptionCode && (
          <Card style={[styles.card, { borderColor: colors.warning + "40" }]}>
            <Text style={[styles.cardTitle, { color: colors.warning }]}>
              كود الموافقة
            </Text>
            <View style={[styles.dataRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.dataValue, { color: colors.foreground }]}>{invoice.exceptionCode}</Text>
              <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>كود الموافقة</Text>
            </View>
            {invoice.exceptionNotes ? (
              <Text style={[styles.dataLabel, { color: colors.mutedForeground, textAlign: "right" }]}>
                {invoice.exceptionNotes}
              </Text>
            ) : null}
          </Card>
        )}
        {invoice.notes ? (
          <Card style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>ملاحظات الفاتورة</Text>
            <Text style={[styles.dataLabel, { color: colors.foreground, textAlign: "right" }]}>{invoice.notes}</Text>
          </Card>
        ) : null}

        {invoice.status !== "cancelled" && invoice.status !== "paid" && (
          <>
            {showPayment ? (
              <Card style={styles.card}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                  تسجيل دفعة
                </Text>
                <Input
                  label={`المبلغ (${currencyMark(payCurrency)}) *`}
                  value={payAmount}
                  onChangeText={(value) => { setPayAmount(value); setPaymentError(""); }}
                  placeholder={`المتبقي: ${formatMoney(remaining, currency)}`}
                  keyboardType="numeric"
                />
                <Text style={[styles.dataLabel, { color: colors.mutedForeground, textAlign: "right" }]}>عملة الدفعة</Text>
                <View style={styles.currencyRow}>
                  {CURRENCIES.map((item) => (
                    <Pressable
                      key={item.code}
                      accessibilityRole="radio"
                      accessibilityState={{ selected: payCurrency === item.code }}
                      onPress={() => {
                        setPayCurrency(item.code);
                        setPayRate(item.code === currency ? String(invoice.exchangeRateToBase ?? "") : "");
                        setPaymentError("");
                      }}
                      style={[styles.currencyChip, { backgroundColor: payCurrency === item.code ? colors.primary : colors.card, borderColor: payCurrency === item.code ? colors.primary : colors.border }]}
                    >
                      <Text style={{ color: payCurrency === item.code ? colors.primaryForeground : colors.foreground, fontSize: 12, fontFamily: "Inter_500Medium" }}>{item.code}</Text>
                    </Pressable>
                  ))}
                </View>
                {payCurrency !== currency && payCurrency !== (entity.baseCurrency ?? "SAR") && (
                  <Input
                    label={`سعر 1 ${currencyMark(payCurrency)} بالعملة الأساسية (${currencyMark(entity.baseCurrency ?? "SAR")})`}
                    value={payRate}
                    onChangeText={setPayRate}
                    placeholder="أدخل سعر الصرف"
                    keyboardType="decimal-pad"
                  />
                )}
                {!invoice.exchangeRateToBase && currency !== (entity.baseCurrency ?? "SAR") && (
                  <Input
                    label={`سعر 1 ${currencyMark(currency)} بالعملة الأساسية (${currencyMark(entity.baseCurrency ?? "SAR")})`}
                    value={invoiceRateOverride}
                    onChangeText={(value) => { setInvoiceRateOverride(value); setPaymentError(""); }}
                    placeholder="أدخل سعر الصرف لهذه الفاتورة القديمة"
                    keyboardType="decimal-pad"
                  />
                )}
                <Input
                  label="ملاحظات"
                  value={payNotes}
                  onChangeText={setPayNotes}
                  placeholder="اختياري"
                />
                {paymentError ? <Text style={[styles.paymentError, { color: colors.destructive }]}>{paymentError}</Text> : null}
                <View style={styles.actionRow}>
                  <Button title="إلغاء" onPress={() => setShowPayment(false)} variant="ghost" style={{ flex: 1 }} />
                  <Button title="حفظ الدفعة" onPress={handleAddPayment} loading={saving} style={{ flex: 1 }} />
                </View>
              </Card>
            ) : (
              <Button
                title="تسجيل دفعة"
                icon={<Feather name="credit-card" size={16} color={colors.primaryForeground} />}
              onPress={() => {
                setPayCurrency(currency);
                setPayRate(String(invoice.exchangeRateToBase ?? ""));
                setInvoiceRateOverride(String(invoice.exchangeRateToBase ?? ""));
                setPaymentError("");
                setShowPayment(true);
              }}
              />
            )}

            <Button
              title="إلغاء الفاتورة"
              variant="destructive"
              onPress={handleCancel}
              disabled={closedInReport}
            />
            {closedInReport && (
              <Text style={[styles.progressLabel, { color: colors.mutedForeground }]}>
                لا يمكن إلغاء فاتورة بعد إغلاق تقريرها. سجّل رفضها من تفاصيل التقرير.
              </Text>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 10,
  },
  title: { flex: 1, fontSize: 18, fontFamily: "Inter_700Bold", textAlign: "right" },
  content: { padding: 16, gap: 16 },
  totalCard: { borderWidth: 2, gap: 10 },
  totalRow: { flexDirection: "row-reverse", justifyContent: "space-between" },
  totalLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  totalAmount: { fontSize: 24, fontFamily: "Inter_700Bold" },
  progressBg: { height: 6, borderRadius: 100, overflow: "hidden" },
  progressFill: { height: 6, borderRadius: 100 },
  progressLabel: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center" },
  card: { gap: 0 },
  cardTitle: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    paddingBottom: 8,
    marginBottom: 4,
  },
  dataRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  dataLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  dataValue: { fontSize: 14, fontFamily: "Inter_500Medium" },
  calcValue: { fontSize: 15, fontFamily: "Inter_700Bold" },
  actionRow: { flexDirection: "row", gap: 10 },
  currencyRow: { flexDirection: "row-reverse", gap: 8 },
  currencyChip: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  paymentError: { fontSize: 12, textAlign: "right", fontFamily: "Inter_500Medium" },
});
