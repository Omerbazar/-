import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp, generateId, Subscriber } from "@/context/AppContext";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export default function NewSubscriberScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { employers, addSubscriber, entity, insuranceCompanies } = useApp();

  const [cardCode, setCardCode] = useState("");
  const [name, setName] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [insuranceStart, setInsuranceStart] = useState("");
  const [insuranceEnd, setInsuranceEnd] = useState("");
  const [selectedEmployerId, setSelectedEmployerId] = useState("");
  const [selectedSectionId, setSelectedSectionId] = useState("");
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const selectedEmployer = employers.find((e) => e.id === selectedEmployerId);
  const selectedSection = selectedEmployer?.sections.find(
    (s) => s.id === selectedSectionId
  );

  function validate() {
    const e: Record<string, string> = {};
    if (!cardCode.trim()) e.cardCode = "كود البطاقة مطلوب";
    if (!name.trim()) e.name = "الاسم مطلوب";
    if (!selectedEmployerId) e.employer = "جهة العمل مطلوبة";
    if (!selectedSectionId) e.section = "القسم مطلوب";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSave() {
    if (!validate()) return;
    setSaving(true);
    const rates = selectedSection ? selectedSection.rates.filter((r) => r.active) : [];
    const sub: Subscriber = {
      id: generateId(),
      cardCode,
      name,
      birthDate,
      gender,
      address,
      phone,
      insuranceStart,
      insuranceEnd,
      status: "active",
      employerId: selectedEmployerId,
      employerSectionId: selectedSectionId,
      exceptionalRates: [],
      notes: notes.trim(),
    };
    await addSubscriber(sub);
    setSaving(false);
    router.back();
  }

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topPt + 12,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable onPress={() => router.back()}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]}>
          مشترك جديد
        </Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingBottom:
              Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            البيانات الأساسية
          </Text>
          <Input
            label="كود البطاقة *"
            value={cardCode}
            onChangeText={setCardCode}
            placeholder="أدخل كود البطاقة"
            error={errors.cardCode}
          />
          <Input
            label="الاسم الكامل *"
            value={name}
            onChangeText={setName}
            placeholder="أدخل الاسم"
            error={errors.name}
          />
          <View style={styles.row}>
            <View style={{ flex: 1, gap: 6 }}>
              <Text style={[styles.label, { color: colors.foreground }]}>
                الجنس
              </Text>
              <View style={styles.genderRow}>
                {(["male", "female"] as const).map((g) => (
                  <Pressable
                    key={g}
                    onPress={() => setGender(g)}
                    style={[
                      styles.genderBtn,
                      {
                        backgroundColor:
                          gender === g ? colors.primary : colors.card,
                        borderColor:
                          gender === g ? colors.primary : colors.border,
                      },
                    ]}
                  >
                    <Text
                      style={{
                        color:
                          gender === g
                            ? colors.primaryForeground
                            : colors.foreground,
                        fontFamily: "Inter_500Medium",
                        fontSize: 13,
                      }}
                    >
                      {g === "male" ? "ذكر" : "أنثى"}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          </View>
          <Input
            label="تاريخ الميلاد"
            value={birthDate}
            onChangeText={setBirthDate}
            placeholder="YYYY-MM-DD"
          />
          <Input
            label="رقم الجوال"
            value={phone}
            onChangeText={setPhone}
            placeholder="05xxxxxxxx"
            keyboardType="phone-pad"
          />
          <Input
            label="العنوان"
            value={address}
            onChangeText={setAddress}
            placeholder="المدينة، الحي"
          />
          <Input
            label="ملاحظات المشترك"
            value={notes}
            onChangeText={setNotes}
            placeholder="معلومة اختيارية للمتابعة"
            multiline
          />
        </Card>

        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            بيانات التأمين
          </Text>
          <Input
            label="تاريخ بداية التأمين"
            value={insuranceStart}
            onChangeText={setInsuranceStart}
            placeholder="YYYY-MM-DD"
          />
          <Input
            label="تاريخ نهاية التأمين"
            value={insuranceEnd}
            onChangeText={setInsuranceEnd}
            placeholder="YYYY-MM-DD"
          />
        </Card>

        <Card style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            جهة العمل والقسم *
          </Text>
          {errors.employer && (
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              {errors.employer}
            </Text>
          )}
          <View style={styles.chipGroup}>
            {employers.map((emp) => (
              <Pressable
                key={emp.id}
                onPress={() => {
                  setSelectedEmployerId(emp.id);
                  setSelectedSectionId("");
                }}
                style={[
                  styles.chip,
                  {
                    backgroundColor:
                      selectedEmployerId === emp.id
                        ? colors.primary
                        : colors.card,
                    borderColor:
                      selectedEmployerId === emp.id
                        ? colors.primary
                        : colors.border,
                  },
                ]}
              >
                <Text
                  style={{
                    color:
                      selectedEmployerId === emp.id
                        ? colors.primaryForeground
                        : colors.foreground,
                    fontFamily: "Inter_500Medium",
                    fontSize: 13,
                  }}
                >
                  {emp.name}
                </Text>
              </Pressable>
            ))}
          </View>

          {selectedEmployer && (
            <>
              <Text style={[styles.label, { color: colors.foreground }]}>
                القسم التأميني *
              </Text>
              {errors.section && (
                <Text style={[styles.errorText, { color: colors.destructive }]}>
                  {errors.section}
                </Text>
              )}
              <View style={styles.chipGroup}>
                {selectedEmployer.sections.map((sec) => (
                  <Pressable
                    key={sec.id}
                    onPress={() => setSelectedSectionId(sec.id)}
                    style={[
                      styles.chip,
                      {
                        backgroundColor:
                          selectedSectionId === sec.id
                            ? colors.accent
                            : colors.card,
                        borderColor:
                          selectedSectionId === sec.id
                            ? colors.accent
                            : colors.border,
                      },
                    ]}
                  >
                    <Text
                      style={{
                        color:
                          selectedSectionId === sec.id
                            ? colors.primaryForeground
                            : colors.foreground,
                        fontFamily: "Inter_500Medium",
                        fontSize: 13,
                      }}
                    >
                      {sec.name}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </>
          )}

          {selectedSection && selectedSection.rates.length > 0 && (
            <View
              style={[styles.ratePreview, { backgroundColor: colors.muted, borderRadius: 10 }]}
            >
              <Text style={[styles.label, { color: colors.foreground, marginBottom: 6 }]}>
                نسب التحمل المرتبطة:
              </Text>
              {selectedSection.rates.filter((r) => r.active).map((r) => (
                <View key={r.id} style={styles.rateRow}>
                  <Text style={[styles.ratePercent, { color: colors.primary }]}>
                    {r.percent}%
                  </Text>
                  <Text style={[styles.rateName, { color: colors.foreground }]}>
                    {r.name}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </Card>

        <Button
          title="حفظ المشترك"
          onPress={handleSave}
          loading={saving}
          style={{ marginHorizontal: 0 }}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  title: { fontSize: 18, fontFamily: "Inter_700Bold" },
  content: { padding: 16, gap: 16 },
  section: { gap: 12 },
  sectionTitle: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    marginBottom: 4,
  },
  label: { fontSize: 14, fontFamily: "Inter_500Medium", textAlign: "right" },
  row: { flexDirection: "row", gap: 12 },
  genderRow: { flexDirection: "row", gap: 8 },
  genderBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
  },
  chipGroup: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 100,
    borderWidth: 1,
  },
  ratePreview: { padding: 12, gap: 6 },
  rateRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  rateName: { fontSize: 13, fontFamily: "Inter_500Medium" },
  ratePercent: { fontSize: 13, fontFamily: "Inter_700Bold" },
  errorText: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "right" },
});
