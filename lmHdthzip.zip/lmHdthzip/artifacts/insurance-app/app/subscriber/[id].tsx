import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import {
  useApp,
  generateId,
  ExceptionalRate,
  CoinsuranceRate,
  Subscriber,
} from "@/context/AppContext";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { formatMoney, invoiceCurrency } from "@/utils/accounting";

export default function SubscriberDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const {
    subscribers,
    employers,
    insuranceCompanies,
    updateSubscriber,
    invoices,
    entity,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
  } = useApp();

  const subscriber = subscribers.find((s) => s.id === id);
  const [showAddRate, setShowAddRate] = useState(false);
  const [rateName, setRateName] = useState("");
  const [ratePercent, setRatePercent] = useState("");
  const [rateCeiling, setRateCeiling] = useState("");
  const [rateNotes, setRateNotes] = useState("");

  if (!subscriber)
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground, padding: 20, textAlign: "right" }}>
          المشترك غير موجود
        </Text>
      </View>
    );

  const currentSubscriber = subscriber;
  const employer = employers.find((e) => e.id === subscriber.employerId);
  const section = employer?.sections.find(
    (s) => s.id === subscriber.employerSectionId
  );
  const insuranceCompany = employer
    ? insuranceCompanies.find((c) => c.id === employer.insuranceCompanyId)
    : undefined;

  const subInvoices = invoices.filter((i) => i.subscriberId === id && i.status !== "cancelled");

  async function handleAddExceptionalRate() {
    if (!rateName || !ratePercent) return;
    const rate: ExceptionalRate = {
      id: generateId(),
      name: rateName,
      percent: parseFloat(ratePercent),
      ceiling: rateCeiling ? parseFloat(rateCeiling) : 0,
      notes: rateNotes,
    };
    const updated = {
      ...currentSubscriber,
      exceptionalRates: [...currentSubscriber.exceptionalRates, rate],
    };
    await updateSubscriber(updated);
    setRateName("");
    setRatePercent("");
    setRateCeiling("");
    setRateNotes("");
    setShowAddRate(false);
  }

  async function toggleStatus() {
    const updated: Subscriber = {
      ...currentSubscriber,
      status:
        currentSubscriber.status === "active" ? "inactive" : "active",
    };
    await updateSubscriber(updated);
  }

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topPt + 12,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable onPress={() => router.back()}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={1}>
          {subscriber.name}
        </Text>
        <Badge
          label={subscriber.status === "active" ? "نشط" : "موقوف"}
          variant={subscriber.status === "active" ? "success" : "muted"}
        />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.card}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>
            البيانات الأساسية
          </Text>
          {[
            { label: "كود البطاقة", value: subscriber.cardCode },
            { label: "الجنس", value: subscriber.gender === "male" ? "ذكر" : "أنثى" },
            { label: "تاريخ الميلاد", value: subscriber.birthDate || "غير محدد" },
            { label: "الجوال", value: subscriber.phone || "غير محدد" },
            { label: "العنوان", value: subscriber.address || "غير محدد" },
            { label: "ملاحظات", value: subscriber.notes || "لا توجد ملاحظات" },
          ].map((row) => (
            <View key={row.label} style={[styles.dataRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.dataValue, { color: colors.foreground }]}>
                {row.value}
              </Text>
              <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>
                {row.label}
              </Text>
            </View>
          ))}
        </Card>

        <Card style={styles.card}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>
            بيانات التأمين
          </Text>
          {[
            { label: "جهة العمل", value: employer?.name ?? "غير محدد" },
            { label: "القسم", value: section?.name ?? "غير محدد" },
            { label: "شركة التأمين", value: insuranceCompany?.name ?? "غير محدد" },
            { label: "بداية التأمين", value: subscriber.insuranceStart || "غير محدد" },
            { label: "نهاية التأمين", value: subscriber.insuranceEnd || "غير محدد" },
          ].map((row) => (
            <View key={row.label} style={[styles.dataRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.dataValue, { color: colors.foreground }]}>
                {row.value}
              </Text>
              <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>
                {row.label}
              </Text>
            </View>
          ))}
        </Card>

        {section && section.rates.length > 0 && (
          <Card style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              نسب التحمل
            </Text>
            {section.rates.filter((r) => r.active).map((r) => (
              <View key={r.id} style={[styles.rateRow, { borderBottomColor: colors.border }]}>
                <View style={{ alignItems: "flex-start" }}>
                  {r.ceiling > 0 && (
                    <Text style={[styles.ceiling, { color: colors.mutedForeground }]}>
                      سقف: {formatMoney(r.ceiling, entity.baseCurrency ?? "SAR")}
                    </Text>
                  )}
                  <Text style={[styles.ratePercent, { color: colors.primary }]}>
                    {r.percent}%
                  </Text>
                </View>
                <Text style={[styles.rateName, { color: colors.foreground }]}>
                  {r.name}
                </Text>
              </View>
            ))}
          </Card>
        )}

        {subscriber.exceptionalRates.length > 0 && (
          <Card style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              نسب استثنائية
            </Text>
            {subscriber.exceptionalRates.map((r) => (
              <View key={r.id} style={[styles.rateRow, { borderBottomColor: colors.border }]}>
                <Text style={[styles.ratePercent, { color: colors.accent }]}>
                  {r.percent}%
                </Text>
                <Text style={[styles.rateName, { color: colors.foreground }]}>
                  {r.name}
                </Text>
              </View>
            ))}
          </Card>
        )}

        {showAddRate ? (
          <Card style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              إضافة نسبة استثنائية
            </Text>
            <Input label="اسم النسبة *" value={rateName} onChangeText={setRateName} placeholder="مثال: أدوية مزمنة" />
            <Input label="النسبة (%) *" value={ratePercent} onChangeText={setRatePercent} placeholder="20" keyboardType="numeric" />
            <Input label="سقف الحالة" value={rateCeiling} onChangeText={setRateCeiling} placeholder="0" keyboardType="numeric" />
            <Input label="ملاحظات" value={rateNotes} onChangeText={setRateNotes} placeholder="اختياري" />
            <View style={styles.actionRow}>
              <Button title="إلغاء" onPress={() => setShowAddRate(false)} variant="ghost" style={{ flex: 1 }} />
              <Button title="إضافة" onPress={handleAddExceptionalRate} style={{ flex: 1 }} />
            </View>
          </Card>
        ) : (
          <Button
            title="إضافة نسبة استثنائية"
            variant="secondary"
            icon={<Feather name="plus" size={16} color={colors.secondaryForeground} />}
            onPress={() => setShowAddRate(true)}
          />
        )}

        {subInvoices.length > 0 && (
          <Card style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              الفواتير ({subInvoices.length})
            </Text>
            {subInvoices.slice(0, 5).map((inv) => (
              <Pressable
                key={inv.id}
                onPress={() => router.push(`/invoice/${inv.id}` as any)}
                style={[styles.dataRow, { borderBottomColor: colors.border }]}
              >
                <Badge
                  label={inv.status === "cancelled" ? "ملغاة" : getInvoiceRejectedAmount(inv.id) > 0 ? "مرفوضة جزئيًا" : inv.netAmount - getInvoicePaidAmount(inv.id) <= 0.005 ? "مدفوعة" : getInvoicePaidAmount(inv.id) > 0 ? "جزئية" : "معلقة"}
                  variant={inv.status === "cancelled" ? "error" : getInvoiceRejectedAmount(inv.id) > 0 ? "warning" : inv.netAmount - getInvoicePaidAmount(inv.id) <= 0.005 ? "success" : getInvoicePaidAmount(inv.id) > 0 ? "warning" : "info"}
                />
                <Text style={[styles.dataLabel, { color: colors.foreground }]}>
                  {inv.invoiceNumber} — {formatMoney(inv.netAmount, invoiceCurrency(inv))}
                </Text>
              </Pressable>
            ))}
          </Card>
        )}

        <Button
          title={subscriber.status === "active" ? "تعليق المشترك" : "تفعيل المشترك"}
          variant={subscriber.status === "active" ? "ghost" : "secondary"}
          onPress={toggleStatus}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 10,
  },
  title: { flex: 1, fontSize: 18, fontFamily: "Inter_700Bold", textAlign: "right" },
  content: { padding: 16, gap: 16 },
  card: { gap: 0 },
  cardTitle: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    paddingBottom: 8,
    marginBottom: 4,
  },
  dataRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  dataLabel: { fontSize: 13, fontFamily: "Inter_400Regular" },
  dataValue: { fontSize: 14, fontFamily: "Inter_500Medium" },
  rateRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
  },
  rateName: { fontSize: 14, fontFamily: "Inter_500Medium" },
  ratePercent: { fontSize: 16, fontFamily: "Inter_700Bold" },
  ceiling: { fontSize: 11, fontFamily: "Inter_400Regular" },
  actionRow: { flexDirection: "row", gap: 10 },
});
