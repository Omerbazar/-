import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Card } from "@/components/ui/Card";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { reportFinancials } from "@/utils/accounting";

const destinations = [
  {
    title: "التقارير الدورية",
    subtitle: "جهّز مطالبات شركات التأمين، راجع الفواتير ثم أغلق الفترة بأمان.",
    icon: "calendar",
    route: "/periodic-reports",
    tint: "primary",
  },
  {
    title: "تقارير خاصة",
    subtitle: "استخرج تقريرًا حسب المدة أو الشركة أو القسم أو المشترك دون تغيير الحسابات.",
    icon: "sliders",
    route: "/special-reports",
    tint: "accent",
  },
  {
    title: "أرشيف التقارير",
    subtitle: "تابع التقارير المغلقة والمدفوعات والمبالغ المرفوضة وأسبابها.",
    icon: "archive",
    route: "/report-archive",
    tint: "warning",
  },
  {
    title: "إعدادات التقارير",
    subtitle: "اختر دورة الإعداد، وطريقة تقسيم المطالبات حسب الأقسام.",
    icon: "settings",
    route: "/report-settings",
    tint: "mutedForeground",
  },
] as const;

export default function ReportsHubScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { reports, invoices } = useApp();
  const unsettled = reports.filter((report) => reportFinancials(report, invoices).outstanding > 0.005).length;
  const rejectedCount = reports.reduce((sum, report) => sum + report.rejections.length, 0);
  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topInset + 16,
          paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.heading}>
        <Text style={[styles.title, { color: colors.foreground }]}>التقارير</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          إعداد المطالبات ومراجعتها وحفظ سجلها المالي
        </Text>
      </View>

      <Card style={styles.statusCard}>
        <View style={[styles.statusIcon, { backgroundColor: colors.warning + "18" }]}>
          <Feather name="clock" size={18} color={colors.warning} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.statusTitle, { color: colors.foreground }]}>
            متابعة الأرشيف
          </Text>
          <Text style={[styles.statusDescription, { color: colors.mutedForeground }]}>
            {unsettled} تقريرًا بمتبقي للتحصيل · {rejectedCount} فاتورة مرفوضة
          </Text>
        </View>
        <Feather name="chevron-left" size={18} color={colors.mutedForeground} />
      </Card>

      <View style={styles.menu}>
        {destinations.map((item, index) => {
          const tint = colors[item.tint];
          return (
            <Pressable
              key={item.route}
              accessibilityRole="button"
              onPress={() => router.push(item.route as any)}
              style={({ pressed }) => [{ opacity: pressed ? 0.76 : 1 }]}
            >
              <Card style={styles.menuCard}>
                <View style={[styles.iconWrap, { backgroundColor: tint + "16" }]}>
                  <Feather name={item.icon as any} size={20} color={tint} />
                </View>
                <View style={styles.menuCopy}>
                  <Text style={[styles.menuTitle, { color: colors.foreground }]}>
                    {item.title}
                  </Text>
                  <Text style={[styles.menuSubtitle, { color: colors.mutedForeground }]}>
                    {item.subtitle}
                  </Text>
                </View>
                <Feather name="chevron-left" size={18} color={colors.mutedForeground} />
              </Card>
            </Pressable>
          );
        })}
      </View>

      <View style={[styles.notice, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
        <Feather name="shield" size={16} color={colors.primary} />
        <Text style={[styles.noticeText, { color: colors.secondaryForeground }]}>
          إغلاق التقرير إجراء محاسبي نهائي لمنع تكرار الفواتير. مشاركة الملف لا تعني أن شركة التأمين استلمته، لذلك يلزم تأكيد الإغلاق يدويًا بعد المراجعة.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 16 },
  heading: { gap: 4 },
  title: { fontSize: 22, fontFamily: "Inter_700Bold", textAlign: "right" },
  subtitle: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "right", lineHeight: 18 },
  statusCard: { flexDirection: "row-reverse", alignItems: "center", gap: 12 },
  statusIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  statusTitle: { textAlign: "right", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  statusDescription: { textAlign: "right", fontSize: 11, marginTop: 3, fontFamily: "Inter_400Regular" },
  menu: { gap: 10 },
  menuCard: { flexDirection: "row-reverse", alignItems: "center", gap: 12, minHeight: 92 },
  iconWrap: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  menuCopy: { flex: 1, gap: 4 },
  menuTitle: { textAlign: "right", fontSize: 15, fontFamily: "Inter_700Bold" },
  menuSubtitle: { textAlign: "right", fontSize: 11, lineHeight: 17, fontFamily: "Inter_400Regular" },
  notice: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 9, borderWidth: 1, borderRadius: 12, padding: 12 },
  noticeText: { flex: 1, textAlign: "right", fontSize: 11, lineHeight: 18, fontFamily: "Inter_400Regular" },
});

