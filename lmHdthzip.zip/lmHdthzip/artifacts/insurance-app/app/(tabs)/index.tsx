import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import { formatMoney, invoiceCurrency } from "@/utils/accounting";
import { StatCard } from "@/components/ui/StatCard";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    subscribers,
    invoices,
    entity,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
  } = useApp();

  const stats = useMemo(() => {
    const active = invoices.filter((i) => i.status !== "cancelled");
    const baseCurrency = entity.baseCurrency ?? "SAR";
    const base = active.filter((invoice) => invoiceCurrency(invoice) === baseCurrency);
    const byCurrency = [...new Set(active.map((invoice) => invoiceCurrency(invoice)))].map((currency) => {
      const items = active.filter((invoice) => invoiceCurrency(invoice) === currency);
      return {
        currency,
        billed: items.reduce((sum, invoice) => sum + invoice.totalAmount, 0),
        paid: items.reduce((sum, invoice) => sum + getInvoicePaidAmount(invoice.id), 0),
        due: items.reduce(
          (sum, invoice) =>
            sum +
            Math.max(
              0,
              invoice.netAmount -
                getInvoicePaidAmount(invoice.id) -
                getInvoiceRejectedAmount(invoice.id)
            ),
          0
        ),
      };
    });
    const totalPaid = base.reduce((sum, invoice) => sum + getInvoicePaidAmount(invoice.id), 0);
    const totalPending = base.reduce(
      (sum, invoice) =>
        sum +
        Math.max(
          0,
          invoice.netAmount -
            getInvoicePaidAmount(invoice.id) -
            getInvoiceRejectedAmount(invoice.id)
        ),
      0
    );
    const paidCount = active.filter(
      (invoice) =>
        invoice.netAmount - getInvoicePaidAmount(invoice.id) <= 0.005 &&
        getInvoiceRejectedAmount(invoice.id) <= 0.005
    ).length;
    const partialCount = active.filter(
      (invoice) => getInvoicePaidAmount(invoice.id) > 0 && invoice.netAmount - getInvoicePaidAmount(invoice.id) > 0.005
    ).length;
    return {
      totalBilled: base.reduce((sum, invoice) => sum + invoice.totalAmount, 0),
      totalPaid,
      totalPending,
      paidCount,
      partialCount,
      byCurrency,
      baseCurrency,
    };
  }, [invoices, entity.baseCurrency, getInvoicePaidAmount, getInvoiceRejectedAmount]);

  const recentInvoices = useMemo(
    () =>
      [...invoices]
        .filter((i) => i.status !== "cancelled")
        .sort((a, b) => b.date.localeCompare(a.date))
        .slice(0, 5),
    [invoices]
  );

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPt + 16,
          paddingBottom:
            Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={[styles.greeting, { color: colors.mutedForeground }]}>
            مرحباً بك
          </Text>
          <Text style={[styles.entityName, { color: colors.foreground }]}>
            {entity.name}
          </Text>
        </View>
        <Pressable
          onPress={() => router.push("/settings")}
          style={[styles.settingsBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <Feather name="settings" size={20} color={colors.primary} />
        </Pressable>
      </View>

      <View style={styles.statsGrid}>
        <StatCard
          label="إجمالي الفواتير"
           value={formatMoney(stats.totalBilled, stats.baseCurrency)}
          accentColor={colors.primary}
          icon={<Feather name="file-text" size={18} color={colors.primary} />}
          style={{ flex: 1 }}
        />
        <StatCard
          label="المدفوعات"
           value={formatMoney(stats.totalPaid, stats.baseCurrency)}
          accentColor={colors.success}
          icon={<Feather name="check-circle" size={18} color={colors.success} />}
          style={{ flex: 1 }}
        />
      </View>
      <View style={styles.statsGrid}>
        <StatCard
          label="المستحقات"
           value={formatMoney(stats.totalPending, stats.baseCurrency)}
          accentColor={colors.warning}
          icon={<Feather name="clock" size={18} color={colors.warning} />}
          style={{ flex: 1 }}
        />
        <StatCard
          label="المشتركون"
          value={subscribers.filter((s) => s.status === "active").length}
          accentColor={colors.accent}
          icon={<Feather name="users" size={18} color={colors.accent} />}
          style={{ flex: 1 }}
        />
      </View>

      {stats.byCurrency.length > 1 && (
        <Card style={{ gap: 9 }}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, textAlign: "right" }]}>
            الأرصدة مفصّلة حسب العملة
          </Text>
          {stats.byCurrency.map((item) => (
            <View key={item.currency} style={[styles.currencyRow, { borderBottomColor: colors.border }]}>
              <View style={{ alignItems: "flex-start" }}>
                <Text style={[styles.currencyAmount, { color: colors.warning }]}>{formatMoney(item.due, item.currency)}</Text>
                <Text style={[styles.currencyMeta, { color: colors.mutedForeground }]}>المتبقي</Text>
              </View>
              <View style={{ alignItems: "flex-end" }}>
                <Text style={[styles.currencyAmount, { color: colors.foreground }]}>{formatMoney(item.billed, item.currency)}</Text>
                <Text style={[styles.currencyMeta, { color: colors.mutedForeground }]}>الإجمالي · المحصّل {formatMoney(item.paid, item.currency)}</Text>
              </View>
            </View>
          ))}
          <Text style={[styles.currencyMeta, { color: colors.mutedForeground, textAlign: "right" }]}>
            البطاقات أعلاه تعرض {stats.baseCurrency} فقط. لا يتم جمع العملات المختلفة أو تحويل السجلات القديمة تلقائيًا.
          </Text>
        </Card>
      )}

      <View style={styles.quickActions}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          الوصول السريع
        </Text>
        <View style={styles.actionsRow}>
          {[
            {
              icon: "plus-circle" as const,
              label: "فاتورة جديدة",
              route: "/invoice/new",
              color: colors.primary,
            },
            {
              icon: "user-plus" as const,
              label: "مشترك جديد",
              route: "/subscriber/new",
              color: colors.accent,
            },
            {
              icon: "briefcase" as const,
              label: "جهات العمل",
              route: "/employers",
              color: colors.warning,
            },
            {
              icon: "shield" as const,
              label: "شركات التأمين",
              route: "/companies",
              color: colors.success,
            },
          ].map((action) => (
            <Pressable
              key={action.label}
              onPress={() => router.push(action.route as any)}
              style={({ pressed }) => [
                styles.actionBtn,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <View
                style={[
                  styles.actionIcon,
                  { backgroundColor: action.color + "18" },
                ]}
              >
                <Feather name={action.icon} size={20} color={action.color} />
              </View>
              <Text
                style={[
                  styles.actionLabel,
                  { color: colors.foreground },
                ]}
                numberOfLines={2}
              >
                {action.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          آخر الفواتير
        </Text>
        {recentInvoices.length === 0 ? (
          <Card>
            <Text
              style={[
                styles.emptyText,
                { color: colors.mutedForeground, textAlign: "center" },
              ]}
            >
              لا توجد فواتير بعد
            </Text>
          </Card>
        ) : (
          recentInvoices.map((inv) => (
            <Pressable
              key={inv.id}
              onPress={() => router.push(`/invoice/${inv.id}` as any)}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <Card style={styles.invoiceCard}>
                <View style={styles.invoiceRow}>
                  <Badge
                    label={
                      inv.status === "cancelled"
                        ? "ملغاة"
                        : getInvoiceRejectedAmount(inv.id) > 0
                          ? "مرفوضة جزئيًا"
                          : inv.netAmount - getInvoicePaidAmount(inv.id) <= 0.005
                        ? "مدفوعة"
                        : getInvoicePaidAmount(inv.id) > 0
                          ? "جزئية"
                          : "معلقة"
                    }
                    variant={
                      inv.status === "cancelled"
                        ? "error"
                        : getInvoiceRejectedAmount(inv.id) > 0
                          ? "warning"
                          : inv.netAmount - getInvoicePaidAmount(inv.id) <= 0.005
                        ? "success"
                        : getInvoicePaidAmount(inv.id) > 0
                          ? "warning"
                          : "info"
                    }
                  />
                  <Text
                    style={[styles.invoiceName, { color: colors.foreground }]}
                    numberOfLines={1}
                  >
                    {inv.subscriberName}
                  </Text>
                </View>
                <View style={styles.invoiceRow}>
                  <Text
                    style={[
                      styles.invoiceAmount,
                      { color: colors.primary },
                    ]}
                  >
                    {formatMoney(inv.netAmount, invoiceCurrency(inv))}
                  </Text>
                  <Text
                    style={[
                      styles.invoiceNumber,
                      { color: colors.mutedForeground },
                    ]}
                  >
                    {inv.invoiceNumber}
                  </Text>
                </View>
              </Card>
            </Pressable>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 20 },
  header: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  greeting: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "right" },
  entityName: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
  },
  settingsBtn: {
    width: 42,
    height: 42,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  statsGrid: { flexDirection: "row", gap: 12 },
  quickActions: { gap: 12 },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    marginBottom: 4,
  },
  currencyRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, paddingVertical: 7 },
  currencyAmount: { fontSize: 12, fontFamily: "Inter_700Bold" },
  currencyMeta: { fontSize: 10, fontFamily: "Inter_400Regular" },
  actionsRow: { flexDirection: "row", gap: 10, flexWrap: "wrap" },
  actionBtn: {
    flex: 1,
    minWidth: "44%",
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    gap: 8,
  },
  actionIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  actionLabel: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
  },
  invoiceCard: { marginBottom: 8, gap: 8 },
  invoiceRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  invoiceName: { fontSize: 14, fontFamily: "Inter_600SemiBold", flex: 1, textAlign: "right", marginLeft: 8 },
  invoiceNumber: { fontSize: 12, fontFamily: "Inter_400Regular" },
  invoiceAmount: { fontSize: 15, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular" },
});
