import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import { formatMoney, invoiceCurrency } from "@/utils/accounting";
import { SearchBar } from "@/components/ui/SearchBar";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/EmptyState";
import { Card } from "@/components/ui/Card";

type FilterStatus = "all" | "pending" | "partial" | "paid" | "rejected" | "cancelled";

export default function InvoicesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { invoices, getInvoicePaidAmount, getInvoiceRejectedAmount } = useApp();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterStatus>("all");

  const filtered = useMemo(() => {
    let list = [...invoices].sort((a, b) => b.date.localeCompare(a.date));
    if (filter !== "all") list = list.filter((invoice) => {
      if (filter === "cancelled") return invoice.status === "cancelled";
      if (invoice.status === "cancelled") return false;
      const paid = getInvoicePaidAmount(invoice.id);
      const rejected = getInvoiceRejectedAmount(invoice.id);
      const remaining = invoice.netAmount - paid - rejected;
      if (filter === "rejected") return rejected > 0;
      if (filter === "paid") return remaining <= 0.005 && rejected <= 0.005;
      if (filter === "partial") return paid > 0 && remaining > 0.005;
      return paid <= 0 && remaining > 0.005;
    });
    const q = search.trim().toLowerCase();
    if (q)
      list = list.filter(
        (i) =>
          i.subscriberName.includes(q) ||
          i.invoiceNumber.includes(q) ||
          i.employerName.includes(q)
      );
    return list;
  }, [invoices, filter, search, getInvoicePaidAmount, getInvoiceRejectedAmount]);

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  const filters: { key: FilterStatus; label: string }[] = [
    { key: "all", label: "الكل" },
    { key: "pending", label: "معلقة" },
    { key: "partial", label: "جزئية" },
    { key: "paid", label: "مدفوعة" },
    { key: "rejected", label: "مرفوضة" },
    { key: "cancelled", label: "ملغاة" },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          {
            paddingTop: topPt + 16,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <View style={styles.headerRow}>
          <Pressable
            onPress={() => router.push("/invoice/new")}
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
          >
            <Feather name="plus" size={20} color="#fff" />
          </Pressable>
          <Text style={[styles.title, { color: colors.foreground }]}>
            الفواتير
          </Text>
        </View>
        <SearchBar
          value={search}
          onChangeText={setSearch}
          placeholder="بحث برقم الفاتورة أو اسم المشترك..."
        />
        <View style={styles.filterRow}>
          {filters.map((f) => (
            <Pressable
              key={f.key}
              onPress={() => setFilter(f.key)}
              style={[
                styles.filterChip,
                {
                  backgroundColor:
                    filter === f.key ? colors.primary : colors.card,
                  borderColor:
                    filter === f.key ? colors.primary : colors.border,
                },
              ]}
            >
              <Text
                style={[
                  styles.filterLabel,
                  {
                    color:
                      filter === f.key
                        ? colors.primaryForeground
                        : colors.foreground,
                  },
                ]}
              >
                {f.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.list,
          {
            paddingBottom:
              Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <EmptyState
            icon="file-text"
            title="لا توجد فواتير"
            subtitle="اضغط + لإنشاء فاتورة جديدة"
          />
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => router.push(`/invoice/${item.id}` as any)}
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <Card style={styles.card}>
              <View style={styles.cardTop}>
                <Badge
                  label={
                    item.status === "cancelled"
                      ? "ملغاة"
                      : getInvoiceRejectedAmount(item.id) > 0
                        ? "مرفوضة جزئيًا"
                        : item.netAmount - getInvoicePaidAmount(item.id) <= 0.005
                      ? "مدفوعة"
                      : getInvoicePaidAmount(item.id) > 0
                        ? "جزئية"
                        : "معلقة"
                  }
                  variant={
                    item.status === "cancelled"
                      ? "error"
                      : getInvoiceRejectedAmount(item.id) > 0
                        ? "warning"
                        : item.netAmount - getInvoicePaidAmount(item.id) <= 0.005
                      ? "success"
                      : getInvoicePaidAmount(item.id) > 0
                        ? "warning"
                        : "info"
                  }
                />
                <View style={{ flex: 1, alignItems: "flex-end" }}>
                  <Text
                    style={[styles.subscriberName, { color: colors.foreground }]}
                    numberOfLines={1}
                  >
                    {item.subscriberName}
                  </Text>
                  <Text
                    style={[styles.invoiceNum, { color: colors.mutedForeground }]}
                  >
                    {item.invoiceNumber}
                  </Text>
                </View>
              </View>
              <View style={styles.amountRow}>
                <View style={{ alignItems: "flex-start" }}>
                  <Text
                    style={[styles.remaining, { color: colors.mutedForeground }]}
                  >
                    متبقي:{" "}
                    <Text style={{ color: colors.warning }}>
                      {formatMoney(Math.max(0, item.netAmount - getInvoicePaidAmount(item.id) - getInvoiceRejectedAmount(item.id)), invoiceCurrency(item))}
                    </Text>
                  </Text>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text
                    style={[styles.amountLabel, { color: colors.mutedForeground }]}
                  >
                    الصافي
                  </Text>
                  <Text style={[styles.amount, { color: colors.primary }]}>
                      {formatMoney(item.netAmount, invoiceCurrency(item))}
                  </Text>
                </View>
              </View>
            </Card>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 12,
  },
  headerRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: { fontSize: 22, fontFamily: "Inter_700Bold" },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  filterRow: { flexDirection: "row-reverse", gap: 8, flexWrap: "wrap" },
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 100,
    borderWidth: 1,
  },
  filterLabel: { fontSize: 12, fontFamily: "Inter_500Medium" },
  list: { paddingHorizontal: 16, paddingTop: 12, gap: 8 },
  card: { gap: 10 },
  cardTop: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 10 },
  subscriberName: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  invoiceNum: { fontSize: 12, fontFamily: "Inter_400Regular" },
  amountRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "flex-end",
  },
  amountLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  amount: { fontSize: 18, fontFamily: "Inter_700Bold" },
  remaining: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
