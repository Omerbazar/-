import { Feather } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Card } from "@/components/ui/Card";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatMoney, invoiceCurrency } from "@/utils/accounting";

type Period = "month" | "all";

export default function ActivitySummaryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    invoices,
    subscribers,
    insuranceCompanies,
    entity,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
  } = useApp();
  const [period, setPeriod] = useState<Period>("month");
  const monthStart = new Date();
  monthStart.setDate(1);
  const startKey = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, "0")}-01`;

  const rows = useMemo(() => {
    const active = invoices.filter(
      (invoice) =>
        invoice.status !== "cancelled" &&
        (period === "all" || invoice.date >= startKey)
    );
    const currencies = Array.from(
      new Set(active.map((invoice) => invoiceCurrency(invoice)))
    );
    return currencies.map((currency) => {
      const items = active.filter((invoice) => invoiceCurrency(invoice) === currency);
      const companyRows = insuranceCompanies
        .map((company) => {
          const companyInvoices = items.filter(
            (invoice) => invoice.insuranceCompanyId === company.id
          );
          const departments = entity.departments
            .map((department) => {
              const departmentInvoices = companyInvoices.filter(
                (invoice) => invoice.serviceDepartmentId === department.id
              );
              return {
                name: department.name,
                count: departmentInvoices.length,
                due: departmentInvoices.reduce(
                  (sum, invoice) =>
                    sum +
                    Math.max(
                      0,
                      invoice.netAmount -
                        getInvoicePaidAmount(invoice.id) -
                        getInvoiceRejectedAmount(invoice.id)
                    ),
                  0
                ),
              };
            })
            .filter((department) => department.count > 0);
          return {
            id: company.id,
            name: company.name,
            count: companyInvoices.length,
            total: companyInvoices.reduce((sum, invoice) => sum + invoice.netAmount, 0),
            paid: companyInvoices.reduce(
              (sum, invoice) => sum + getInvoicePaidAmount(invoice.id),
              0
            ),
            due: companyInvoices.reduce(
              (sum, invoice) =>
                sum +
                Math.max(
                  0,
                  invoice.netAmount -
                    getInvoicePaidAmount(invoice.id) -
                    getInvoiceRejectedAmount(invoice.id)
                ),
              0
            ),
            departments,
          };
        })
        .filter((company) => company.count > 0);
      return {
        currency,
        count: items.length,
        billed: items.reduce((sum, invoice) => sum + invoice.totalAmount, 0),
        coinsurance: items.reduce((sum, invoice) => sum + invoice.coinsuranceAmount, 0),
        discounts: items.reduce((sum, invoice) => sum + invoice.discountAmount, 0),
        net: items.reduce((sum, invoice) => sum + invoice.netAmount, 0),
        paid: items.reduce((sum, invoice) => sum + getInvoicePaidAmount(invoice.id), 0),
        due: items.reduce(
          (sum, invoice) =>
            sum +
            Math.max(
              0,
              invoice.netAmount -
                getInvoicePaidAmount(invoice.id) -
                getInvoiceRejectedAmount(invoice.id)
            ),
          0
        ),
        rejected: items.reduce(
          (sum, invoice) => sum + getInvoiceRejectedAmount(invoice.id),
          0
        ),
        paidInvoices: items.filter(
          (invoice) =>
            invoice.netAmount - getInvoicePaidAmount(invoice.id) <= 0.005
        ).length,
        companyRows,
      };
    });
  }, [
    invoices,
    insuranceCompanies,
    entity.departments,
    period,
    startKey,
    getInvoicePaidAmount,
    getInvoiceRejectedAmount,
  ]);

  const topInset = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topInset + 16,
          paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.titleRow}>
        <View style={[styles.titleIcon, { backgroundColor: colors.secondary }]}>
          <Feather name="activity" size={21} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.pageTitle, { color: colors.foreground }]}>
            ملخص الأنشطة
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            متابعة العمليات والتحصيل والمبالغ المستحقة
          </Text>
        </View>
      </View>

      <View style={[styles.periodSwitch, { backgroundColor: colors.muted }]}>
        {([
          ["month", "هذا الشهر"],
          ["all", "كل الفترات"],
        ] as const).map(([key, label]) => (
          <Pressable
            key={key}
            onPress={() => setPeriod(key)}
            style={[
              styles.periodButton,
              {
                backgroundColor: period === key ? colors.card : "transparent",
                borderColor: period === key ? colors.border : "transparent",
              },
            ]}
          >
            <Text
              style={{
                color: period === key ? colors.foreground : colors.mutedForeground,
                fontFamily: period === key ? "Inter_600SemiBold" : "Inter_400Regular",
                fontSize: 13,
              }}
            >
              {label}
            </Text>
          </Pressable>
        ))}
      </View>

      <Card style={styles.card}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>
          حركة الفترة
        </Text>
        <View style={styles.metricGrid}>
          {[
            { label: "الفواتير", value: invoices.filter((invoice) => invoice.status !== "cancelled" && (period === "all" || invoice.date >= startKey)).length, icon: "file-text", color: colors.primary },
            { label: "المشتركون النشطون", value: subscribers.filter((item) => item.status === "active").length, icon: "users", color: colors.accent },
            { label: "الشركات", value: new Set(invoices.filter((invoice) => invoice.status !== "cancelled" && (period === "all" || invoice.date >= startKey)).map((invoice) => invoice.insuranceCompanyId)).size, icon: "briefcase", color: colors.success },
            { label: "الفواتير المدفوعة", value: invoices.filter((invoice) => invoice.status !== "cancelled" && (period === "all" || invoice.date >= startKey) && invoice.netAmount - getInvoicePaidAmount(invoice.id) <= 0.005).length, icon: "check-circle", color: colors.warning },
          ].map((item) => (
            <View key={item.label} style={[styles.metric, { backgroundColor: item.color + "12", borderColor: item.color + "35" }]}>
              <Feather name={item.icon as any} size={17} color={item.color} />
              <Text style={[styles.metricValue, { color: item.color }]}>{item.value}</Text>
              <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>{item.label}</Text>
            </View>
          ))}
        </View>
      </Card>

      {rows.length === 0 ? (
        <Card style={styles.emptyCard}>
          <Feather name="bar-chart-2" size={24} color={colors.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>لا توجد عمليات في هذه الفترة</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>ستظهر الملخصات بعد إضافة الفواتير.</Text>
        </Card>
      ) : (
        rows.map((row) => (
          <React.Fragment key={row.currency}>
            <Card style={styles.card}>
              <View style={styles.currencyTitleRow}>
                <Text style={[styles.currencyBadge, { color: colors.primary, backgroundColor: colors.secondary }]}>
                  {row.currency}
                </Text>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                  الملخص المالي
                </Text>
              </View>
              {[
                { label: "إجمالي الفواتير", value: row.billed, color: colors.foreground },
                { label: "إجمالي التحمل", value: row.coinsurance, color: colors.warning },
                { label: "إجمالي الخصومات", value: row.discounts, color: colors.accent },
                { label: "صافي المطالبات", value: row.net, color: colors.primary },
                { label: "المحصّل", value: row.paid, color: colors.success },
                { label: "المتبقي للتحصيل", value: row.due, color: colors.warning },
                { label: "مبالغ مستبعدة بالرفض", value: row.rejected, color: colors.destructive },
              ].map((item) => (
                <View key={item.label} style={[styles.summaryRow, { borderBottomColor: colors.border }]}>
                  <Text style={[styles.summaryValue, { color: item.color }]}>{formatMoney(item.value, row.currency)}</Text>
                  <Text style={[styles.summaryLabel, { color: colors.foreground }]}>{item.label}</Text>
                </View>
              ))}
            </Card>

            {row.companyRows.length > 0 && (
              <Card style={styles.card}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                  المستحقات حسب شركة التأمين
                </Text>
                {row.companyRows.map((company) => (
                  <View key={company.id} style={[styles.companyBlock, { borderBottomColor: colors.border }]}>
                    <View style={styles.companyRow}>
                      <View style={{ alignItems: "flex-start" }}>
                        <Text style={[styles.companyDue, { color: company.due > 0 ? colors.warning : colors.success }]}>
                          {formatMoney(company.due, row.currency)}
                        </Text>
                        <Text style={[styles.smallText, { color: colors.mutedForeground }]}>
                          {company.count} فاتورة · محصّل {formatMoney(company.paid, row.currency)}
                        </Text>
                      </View>
                      <Text style={[styles.companyName, { color: colors.foreground }]}>{company.name}</Text>
                    </View>
                    {company.departments.map((department) => (
                      <View key={department.name} style={styles.departmentRow}>
                        <Text style={[styles.departmentDue, { color: colors.primary }]}>{formatMoney(department.due, row.currency)}</Text>
                        <Text style={[styles.smallText, { color: colors.mutedForeground }]}>{department.name} · {department.count} فاتورة</Text>
                      </View>
                    ))}
                  </View>
                ))}
              </Card>
            )}
          </React.Fragment>
        ))
      )}
      <Text style={[styles.footnote, { color: colors.mutedForeground }]}>
        يعرض كل نوع عملة في ملخص مستقل لتجنّب جمع مبالغ بعملات مختلفة. قيمة الفواتير القديمة التي لا تحتوي عملة محفوظة تُعرض بالريال السعودي كما كانت تظهر في الإصدار السابق.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 14 },
  titleRow: { flexDirection: "row-reverse", alignItems: "center", gap: 12 },
  titleIcon: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  pageTitle: { fontSize: 22, fontFamily: "Inter_700Bold", textAlign: "right" },
  subtitle: { fontSize: 12, lineHeight: 18, textAlign: "right", fontFamily: "Inter_400Regular" },
  periodSwitch: { flexDirection: "row-reverse", borderRadius: 12, padding: 4 },
  periodButton: { flex: 1, minHeight: 38, borderWidth: 1, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  card: { gap: 12 },
  cardTitle: { fontSize: 15, fontFamily: "Inter_700Bold", textAlign: "right" },
  metricGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  metric: { flex: 1, minWidth: "44%", borderWidth: 1, borderRadius: 12, padding: 12, alignItems: "center", gap: 5 },
  metricValue: { fontSize: 22, fontFamily: "Inter_700Bold" },
  metricLabel: { fontSize: 11, fontFamily: "Inter_400Regular", textAlign: "center" },
  currencyTitleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  currencyBadge: { overflow: "hidden", paddingHorizontal: 9, paddingVertical: 4, borderRadius: 8, fontSize: 11, fontFamily: "Inter_700Bold" },
  summaryRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, paddingVertical: 8 },
  summaryLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  summaryValue: { fontSize: 14, fontFamily: "Inter_700Bold" },
  companyBlock: { paddingBottom: 10, borderBottomWidth: 1, gap: 7 },
  companyRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  companyName: { fontSize: 14, fontFamily: "Inter_600SemiBold", textAlign: "right", flex: 1 },
  companyDue: { fontSize: 15, fontFamily: "Inter_700Bold" },
  smallText: { fontSize: 10, fontFamily: "Inter_400Regular", textAlign: "right" },
  departmentRow: { flexDirection: "row-reverse", justifyContent: "space-between", paddingHorizontal: 8 },
  departmentDue: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  emptyCard: { alignItems: "center", gap: 8, paddingVertical: 26 },
  emptyTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  footnote: { fontSize: 11, lineHeight: 17, textAlign: "right" },
});

