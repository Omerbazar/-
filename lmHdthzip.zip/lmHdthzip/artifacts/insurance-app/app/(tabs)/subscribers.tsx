import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import { SearchBar } from "@/components/ui/SearchBar";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/EmptyState";
import { Card } from "@/components/ui/Card";

export default function SubscribersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { subscribers, employers } = useApp();
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return subscribers;
    return subscribers.filter(
      (s) =>
        s.name.includes(q) ||
        s.cardCode.includes(q) ||
        s.phone.includes(q)
    );
  }, [subscribers, search]);

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          { paddingTop: topPt + 16, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <View style={styles.headerRow}>
          <Pressable
            onPress={() => router.push("/subscriber/new")}
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
          >
            <Feather name="plus" size={20} color="#fff" />
          </Pressable>
          <Text style={[styles.title, { color: colors.foreground }]}>
            المشتركون
          </Text>
        </View>
        <SearchBar
          value={search}
          onChangeText={setSearch}
          placeholder="بحث بالاسم أو كود البطاقة..."
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.list,
          {
            paddingBottom:
              Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <EmptyState
            icon="users"
            title="لا يوجد مشتركون"
            subtitle="اضغط + لإضافة مشترك جديد"
          />
        }
        renderItem={({ item }) => {
          const employer = employers.find((e) => e.id === item.employerId);
          const section = employer?.sections.find(
            (s) => s.id === item.employerSectionId
          );
          return (
            <Pressable
              onPress={() => router.push(`/subscriber/${item.id}` as any)}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <Card style={styles.card}>
                <View style={styles.cardHeader}>
                  <Badge
                    label={item.status === "active" ? "نشط" : "موقوف"}
                    variant={item.status === "active" ? "success" : "muted"}
                  />
                  <View style={styles.nameWrap}>
                    <Text
                      style={[styles.name, { color: colors.foreground }]}
                      numberOfLines={1}
                    >
                      {item.name}
                    </Text>
                    <Text
                      style={[styles.code, { color: colors.mutedForeground }]}
                    >
                      {item.cardCode}
                    </Text>
                  </View>
                  <View
                    style={[
                      styles.avatar,
                      { backgroundColor: colors.primary + "20" },
                    ]}
                  >
                    <Feather name="user" size={20} color={colors.primary} />
                  </View>
                </View>
                {employer && (
                  <View style={styles.metaRow}>
                    <Feather
                      name="briefcase"
                      size={12}
                      color={colors.mutedForeground}
                    />
                    <Text
                      style={[
                        styles.meta,
                        { color: colors.mutedForeground },
                      ]}
                    >
                      {employer.name}
                      {section ? ` — ${section.name}` : ""}
                    </Text>
                  </View>
                )}
                <View style={styles.metaRow}>
                  <Feather
                    name="phone"
                    size={12}
                    color={colors.mutedForeground}
                  />
                  <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                    {item.phone || "غير محدد"}
                  </Text>
                </View>
              </Card>
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 12,
  },
  headerRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: { fontSize: 22, fontFamily: "Inter_700Bold" },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  list: { paddingHorizontal: 16, paddingTop: 12, gap: 8 },
  card: { gap: 8 },
  cardHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  nameWrap: { flex: 1, alignItems: "flex-end" },
  name: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  code: { fontSize: 12, fontFamily: "Inter_400Regular" },
  metaRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
  },
  meta: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
