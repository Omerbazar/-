import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import {
  useApp,
  generateId,
  InsuranceCompany,
  InsuranceDiscount,
} from "@/context/AppContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { EmptyState } from "@/components/ui/EmptyState";

export default function CompaniesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    insuranceCompanies,
    addInsuranceCompany,
    updateInsuranceCompany,
    deleteInsuranceCompany,
    entity,
  } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<InsuranceCompany | null>(null);
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [contractDate, setContractDate] = useState("");
  const [contractCode, setContractCode] = useState("");
  const [discounts, setDiscounts] = useState<InsuranceDiscount[]>([]);

  const topPt = Platform.OS === "web" ? (insets.top || 67) : insets.top;

  function openNew() {
    setEditing(null);
    setCode("");
    setName("");
    setPhone("");
    setEmail("");
    setContractDate("");
    setContractCode("");
    setDiscounts(
      entity.departments.map((d) => ({
        departmentId: d.id,
        departmentName: d.name,
        discountPercent: 0,
      }))
    );
    setShowModal(true);
  }

  function openEdit(c: InsuranceCompany) {
    setEditing(c);
    setCode(c.code);
    setName(c.name);
    setPhone(c.phone);
    setEmail(c.email);
    setContractDate(c.contractDate);
    setContractCode(c.contractCode);
    const existingDiscounts = entity.departments.map((d) => {
      const existing = c.discounts.find((disc) => disc.departmentId === d.id);
      return existing ?? { departmentId: d.id, departmentName: d.name, discountPercent: 0 };
    });
    setDiscounts(existingDiscounts);
    setShowModal(true);
  }

  function setDiscountPercent(deptId: string, val: string) {
    setDiscounts((prev) =>
      prev.map((d) =>
        d.departmentId === deptId
          ? { ...d, discountPercent: parseFloat(val) || 0 }
          : d
      )
    );
  }

  async function handleSave() {
    if (!name.trim()) return;
    const company: InsuranceCompany = {
      id: editing?.id ?? generateId(),
      code,
      name,
      phone,
      email,
      contractDate,
      contractCode,
      discounts,
    };
    if (editing) {
      await updateInsuranceCompany(company);
    } else {
      await addInsuranceCompany(company);
    }
    setShowModal(false);
  }

  async function handleDelete(id: string) {
    Alert.alert("حذف شركة التأمين", "هل أنت متأكد؟", [
      { text: "إلغاء" },
      {
        text: "حذف",
        style: "destructive",
        onPress: () => deleteInsuranceCompany(id),
      },
    ]);
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          {
            paddingTop: topPt + 16,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()}>
            <Feather name="arrow-right" size={24} color={colors.foreground} />
          </Pressable>
          <Pressable
            onPress={openNew}
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
          >
            <Feather name="plus" size={20} color="#fff" />
          </Pressable>
          <Text style={[styles.title, { color: colors.foreground }]}>
            شركات التأمين
          </Text>
        </View>
      </View>

      <FlatList
        data={insuranceCompanies}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.list,
          {
            paddingBottom:
              Platform.OS === "web" ? 34 + 84 : insets.bottom + 100,
          },
        ]}
        ListEmptyComponent={
          <EmptyState
            icon="shield"
            title="لا توجد شركات تأمين"
            subtitle="اضغط + لإضافة شركة تأمين"
          />
        }
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <View style={styles.cardHeader}>
              <View style={{ flexDirection: "row", gap: 10 }}>
                <Pressable onPress={() => openEdit(item)}>
                  <Feather name="edit-2" size={16} color={colors.primary} />
                </Pressable>
                <Pressable onPress={() => handleDelete(item.id)}>
                  <Feather name="trash-2" size={16} color={colors.destructive} />
                </Pressable>
              </View>
              <View style={{ flex: 1, alignItems: "flex-end" }}>
                <Text style={[styles.companyName, { color: colors.foreground }]}>
                  {item.name}
                </Text>
                <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                  {item.code}
                </Text>
              </View>
              <View
                style={[
                  styles.iconWrap,
                  { backgroundColor: colors.success + "18" },
                ]}
              >
                <Feather name="shield" size={20} color={colors.success} />
              </View>
            </View>
            {item.discounts.filter((d) => d.discountPercent > 0).length > 0 && (
              <View style={styles.discountWrap}>
                {item.discounts
                  .filter((d) => d.discountPercent > 0)
                  .map((d) => (
                    <View
                      key={d.departmentId}
                      style={[
                        styles.discountChip,
                        { backgroundColor: colors.success + "15", borderColor: colors.success + "30" },
                      ]}
                    >
                      <Text
                        style={[styles.discountPct, { color: colors.success }]}
                      >
                        {d.discountPercent}%
                      </Text>
                      <Text
                        style={[
                          styles.discountDept,
                          { color: colors.foreground },
                        ]}
                      >
                        {d.departmentName}
                      </Text>
                    </View>
                  ))}
              </View>
            )}
          </Card>
        )}
      />

      <Modal
        visible={showModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View
          style={[
            { flex: 1, backgroundColor: colors.background },
          ]}
        >
          <View
            style={[
              styles.topBar,
              {
                paddingTop: topPt + 16,
                backgroundColor: colors.background,
                borderBottomColor: colors.border,
              },
            ]}
          >
            <View style={styles.headerRow}>
              <Button
                title="إلغاء"
                onPress={() => setShowModal(false)}
                variant="ghost"
                size="sm"
              />
              <Text style={[styles.title, { color: colors.foreground }]}>
                {editing ? "تعديل شركة" : "شركة جديدة"}
              </Text>
              <Button title="حفظ" onPress={handleSave} size="sm" />
            </View>
          </View>
          <ScrollView
            contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 80 }}
          >
            <Card style={{ gap: 12 }}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                بيانات الشركة
              </Text>
              <Input label="كود الشركة" value={code} onChangeText={setCode} placeholder="INS001" />
              <Input label="اسم الشركة *" value={name} onChangeText={setName} placeholder="اسم شركة التأمين" />
              <Input label="رقم التواصل" value={phone} onChangeText={setPhone} placeholder="05xxxxxxxx" keyboardType="phone-pad" />
              <Input label="البريد الإلكتروني" value={email} onChangeText={setEmail} placeholder="info@company.com" keyboardType="email-address" />
              <Input label="تاريخ التعاقد" value={contractDate} onChangeText={setContractDate} placeholder="YYYY-MM-DD" />
              <Input label="كود التعاقد" value={contractCode} onChangeText={setContractCode} placeholder="CTR001" />
            </Card>
            <Card style={{ gap: 12 }}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                نسب الخصم لكل قسم
              </Text>
              {discounts.map((d) => (
                <View key={d.departmentId} style={styles.discountRow}>
                  <Input
                    value={d.discountPercent > 0 ? d.discountPercent.toString() : ""}
                    onChangeText={(v) => setDiscountPercent(d.departmentId, v)}
                    placeholder="0"
                    keyboardType="numeric"
                    containerStyle={{ width: 80 }}
                  />
                  <Text style={[styles.deptLabel, { color: colors.foreground }]}>
                    {d.departmentName}
                  </Text>
                  <Text style={[styles.pctSign, { color: colors.mutedForeground }]}>%</Text>
                </View>
              ))}
            </Card>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 12,
  },
  headerRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: { fontSize: 20, fontFamily: "Inter_700Bold" },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  list: { paddingHorizontal: 16, paddingTop: 12, gap: 8 },
  card: { gap: 8 },
  cardHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  companyName: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  meta: { fontSize: 12, fontFamily: "Inter_400Regular" },
  discountWrap: {
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    gap: 6,
  },
  discountChip: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 100,
    borderWidth: 1,
  },
  discountPct: { fontSize: 13, fontFamily: "Inter_700Bold" },
  discountDept: { fontSize: 12, fontFamily: "Inter_400Regular" },
  sectionTitle: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    marginBottom: 4,
  },
  discountRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
  },
  deptLabel: { flex: 1, fontSize: 14, fontFamily: "Inter_500Medium", textAlign: "right" },
  pctSign: { fontSize: 14, fontFamily: "Inter_400Regular" },
});
