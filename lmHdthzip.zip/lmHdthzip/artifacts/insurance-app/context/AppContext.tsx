import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { loadFacilitySettings, saveFacilitySettings } from "@/data/localDatabase";
import type { Department, MainEntity } from "@/types/facility";
import type { CurrencyCode } from "@/constants/currencies";

export type { Department, MainEntity } from "@/types/facility";
export type { CurrencyCode } from "@/constants/currencies";

export interface InsuranceDiscount {
  departmentId: string;
  departmentName: string;
  discountPercent: number;
}

export interface InsuranceCompany {
  id: string;
  code: string;
  name: string;
  phone: string;
  email: string;
  contractDate: string;
  contractCode: string;
  discounts: InsuranceDiscount[];
}

export interface CoinsuranceRate {
  id: string;
  name: string;
  percent: number;
  ceiling: number;
  notes: string;
  active: boolean;
}

export interface EmployerSection {
  id: string;
  name: string;
  rates: CoinsuranceRate[];
}

export interface Employer {
  id: string;
  code: string;
  name: string;
  location: string;
  phone: string;
  insuranceCompanyId: string;
  sections: EmployerSection[];
}

export interface ExceptionalRate {
  id: string;
  name: string;
  percent: number;
  ceiling: number;
  notes: string;
}

export interface Subscriber {
  id: string;
  cardCode: string;
  name: string;
  birthDate: string;
  gender: "male" | "female";
  address: string;
  phone: string;
  insuranceStart: string;
  insuranceEnd: string;
  status: "active" | "inactive";
  employerId: string;
  employerSectionId: string;
  exceptionalRates: ExceptionalRate[];
  notes?: string;
}

export interface Payment {
  id: string;
  // Amount normalized into the invoice's currency for balance calculations.
  amount: number;
  date: string;
  notes: string;
  currency?: CurrencyCode;
  sourceAmount?: number;
  exchangeRateToBase?: number;
  baseAmount?: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  subscriberId: string;
  subscriberName: string;
  employerId: string;
  employerName: string;
  insuranceCompanyId: string;
  insuranceCompanyName: string;
  serviceDepartmentId: string;
  serviceDepartmentName: string;
  totalAmount: number;
  coinsuranceRateId: string;
  coinsuranceRateName: string;
  coinsurancePercent: number;
  coinsuranceAmount: number;
  discountPercent: number;
  discountAmount: number;
  netAmount: number;
  status: "pending" | "paid" | "partial" | "cancelled";
  date: string;
  exceptionCode: string;
  exceptionNotes: string;
  payments: Payment[];
  paidAmount: number;
  currency?: CurrencyCode;
  exchangeRateToBase?: number;
  baseTotalAmount?: number;
  baseCoinsuranceAmount?: number;
  baseDiscountAmount?: number;
  baseNetAmount?: number;
  notes?: string;
  approvalRequested?: boolean;
}

export interface ReportAllocation {
  invoiceId: string;
  amount: number;
}

export interface ReportSettlement {
  id: string;
  amount: number;
  date: string;
  notes: string;
  allocations: ReportAllocation[];
}

export interface ReportRejection {
  id: string;
  invoiceId: string;
  amount: number;
  reason: string;
  date: string;
}

export interface PeriodicReport {
  id: string;
  kind: "periodic";
  companyId: string;
  companyName: string;
  departmentId: string | null;
  departmentName: string | null;
  currency: CurrencyCode;
  dateFrom: string;
  dateTo: string;
  closedAt: string;
  invoiceIds: string[];
  totalAmount: number;
  settlements: ReportSettlement[];
  rejections: ReportRejection[];
}

export interface ReportSettings {
  cadence: "monthly" | "weekly" | "custom";
  customCycleDays: number;
  splitDepartments: boolean;
}

export const DEFAULT_REPORT_SETTINGS: ReportSettings = {
  cadence: "monthly",
  customCycleDays: 30,
  splitDepartments: true,
};

interface AppContextType {
  entity: MainEntity;
  updateEntity: (entity: MainEntity) => Promise<void>;
  storageError: string | null;
  reloadData: () => Promise<void>;
  insuranceCompanies: InsuranceCompany[];
  addInsuranceCompany: (company: InsuranceCompany) => void;
  updateInsuranceCompany: (company: InsuranceCompany) => void;
  deleteInsuranceCompany: (id: string) => void;
  employers: Employer[];
  addEmployer: (employer: Employer) => void;
  updateEmployer: (employer: Employer) => void;
  deleteEmployer: (id: string) => void;
  subscribers: Subscriber[];
  addSubscriber: (subscriber: Subscriber) => void;
  updateSubscriber: (subscriber: Subscriber) => void;
  deleteSubscriber: (id: string) => void;
  invoices: Invoice[];
  addInvoice: (invoice: Invoice) => void;
  updateInvoice: (invoice: Invoice) => Promise<void>;
  cancelInvoice: (id: string) => Promise<void>;
  addPayment: (invoiceId: string, payment: Payment) => Promise<void>;
  reports: PeriodicReport[];
  reportSettings: ReportSettings;
  updateReportSettings: (settings: ReportSettings) => Promise<void>;
  closeReports: (reports: PeriodicReport[]) => Promise<void>;
  addReportSettlement: (
    reportId: string,
    allocations: ReportAllocation[],
    notes: string
  ) => Promise<void>;
  rejectReportInvoice: (reportId: string, invoiceId: string, reason: string) => Promise<void>;
  getInvoicePaidAmount: (invoiceId: string) => number;
  getInvoiceRejectedAmount: (invoiceId: string) => number;
  isInvoiceInClosedReport: (invoiceId: string) => boolean;
  loading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_ENTITY: MainEntity = {
  id: "1",
  name: "",
  address: "",
  phone: "",
  email: "",
  website: "",
  baseCurrency: null,
  departments: [],
};

function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [entity, setEntity] = useState<MainEntity>(DEFAULT_ENTITY);
  const [insuranceCompanies, setInsuranceCompanies] = useState<
    InsuranceCompany[]
  >([]);
  const [employers, setEmployers] = useState<Employer[]>([]);
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [reports, setReports] = useState<PeriodicReport[]>([]);
  const [reportSettings, setReportSettings] =
    useState<ReportSettings>(DEFAULT_REPORT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    void loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    setStorageError(null);
    try {
      const [
        companiesData,
        employersData,
        subscribersData,
        invoicesData,
        reportsData,
        reportSettingsData,
      ] =
        await Promise.all([
        AsyncStorage.getItem("insuranceCompanies"),
        AsyncStorage.getItem("employers"),
        AsyncStorage.getItem("subscribers"),
        AsyncStorage.getItem("invoices"),
        AsyncStorage.getItem("periodicReports"),
        AsyncStorage.getItem("reportSettings"),
      ]);

      const storedEntity = await loadFacilitySettings(DEFAULT_ENTITY);
      setEntity(storedEntity);
      setInsuranceCompanies(companiesData ? JSON.parse(companiesData) : []);
      setEmployers(employersData ? JSON.parse(employersData) : []);
      setSubscribers(subscribersData ? JSON.parse(subscribersData) : []);
      setInvoices(invoicesData ? JSON.parse(invoicesData) : []);
      setReports(reportsData ? JSON.parse(reportsData) : []);
      setReportSettings(reportSettingsData
        ? { ...DEFAULT_REPORT_SETTINGS, ...JSON.parse(reportSettingsData) }
        : DEFAULT_REPORT_SETTINGS);
    } catch {
      setStorageError(
        "تعذر فتح البيانات المحفوظة. أعد المحاولة، ولا تحذف التطبيق أو بياناته."
      );
    } finally {
      setLoading(false);
    }
  }

  const updateEntity = useCallback(async (e: MainEntity) => {
    await saveFacilitySettings(e);
    setEntity(e);
  }, []);

  const addInsuranceCompany = useCallback(
    async (company: InsuranceCompany) => {
      setInsuranceCompanies((prev) => {
        const updated = [...prev, company];
        AsyncStorage.setItem("insuranceCompanies", JSON.stringify(updated));
        return updated;
      });
    },
    []
  );

  const updateInsuranceCompany = useCallback(
    async (company: InsuranceCompany) => {
      setInsuranceCompanies((prev) => {
        const updated = prev.map((c) => (c.id === company.id ? company : c));
        AsyncStorage.setItem("insuranceCompanies", JSON.stringify(updated));
        return updated;
      });
    },
    []
  );

  const deleteInsuranceCompany = useCallback(async (id: string) => {
    setInsuranceCompanies((prev) => {
      const updated = prev.filter((c) => c.id !== id);
      AsyncStorage.setItem("insuranceCompanies", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const addEmployer = useCallback(async (employer: Employer) => {
    setEmployers((prev) => {
      const updated = [...prev, employer];
      AsyncStorage.setItem("employers", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const updateEmployer = useCallback(async (employer: Employer) => {
    setEmployers((prev) => {
      const updated = prev.map((e) => (e.id === employer.id ? employer : e));
      AsyncStorage.setItem("employers", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const deleteEmployer = useCallback(async (id: string) => {
    setEmployers((prev) => {
      const updated = prev.filter((e) => e.id !== id);
      AsyncStorage.setItem("employers", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const addSubscriber = useCallback(async (subscriber: Subscriber) => {
    setSubscribers((prev) => {
      const updated = [...prev, subscriber];
      AsyncStorage.setItem("subscribers", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const updateSubscriber = useCallback(async (subscriber: Subscriber) => {
    setSubscribers((prev) => {
      const updated = prev.map((s) =>
        s.id === subscriber.id ? subscriber : s
      );
      AsyncStorage.setItem("subscribers", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const deleteSubscriber = useCallback(async (id: string) => {
    setSubscribers((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      AsyncStorage.setItem("subscribers", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const addInvoice = useCallback(async (invoice: Invoice) => {
    setInvoices((prev) => {
      const updated = [...prev, invoice];
      AsyncStorage.setItem("invoices", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const updateInvoice = useCallback(async (invoice: Invoice) => {
    const updated = invoices.map((item) => (item.id === invoice.id ? invoice : item));
    await AsyncStorage.setItem("invoices", JSON.stringify(updated));
    setInvoices(updated);
  }, [invoices]);

  const cancelInvoice = useCallback(async (id: string) => {
    if (reports.some((report) => report.invoiceIds.includes(id))) {
      throw new Error("لا يمكن إلغاء فاتورة ضمن تقرير مغلق. سجّل الرفض أو صحّحها عبر مسار تدقيق التقرير.");
    }
    setInvoices((prev) => {
      const updated = prev.map((i) =>
        i.id === id ? { ...i, status: "cancelled" as const } : i
      );
      AsyncStorage.setItem("invoices", JSON.stringify(updated));
      return updated;
    });
  }, [reports]);

  const addPayment = useCallback(
    async (invoiceId: string, payment: Payment) => {
      const invoice = invoices.find((item) => item.id === invoiceId);
      if (!invoice) throw new Error("الفاتورة غير موجودة.");
      const paidThroughReports = reports.reduce(
        (sum, report) =>
          sum +
          report.settlements.reduce(
            (settlementSum, settlement) =>
              settlementSum +
              settlement.allocations
                .filter((allocation) => allocation.invoiceId === invoiceId)
                .reduce((allocationSum, allocation) => allocationSum + allocation.amount, 0),
            0
          ),
        0
      );
      const rejected = reports.reduce(
        (sum, report) =>
          sum +
          report.rejections
            .filter((rejection) => rejection.invoiceId === invoiceId)
            .reduce((rejectionSum, rejection) => rejectionSum + rejection.amount, 0),
        0
      );
      const available = Math.max(0, invoice.netAmount - invoice.paidAmount - paidThroughReports - rejected);
      if (!Number.isFinite(payment.amount) || payment.amount <= 0 || payment.amount > available + 0.005) {
        throw new Error("مبلغ الدفعة يتجاوز المبلغ المتبقي على الفاتورة.");
      }
      const payments = [...invoice.payments, payment];
      const paidAmount = payments.reduce((sum, item) => sum + item.amount, 0);
      const status: Invoice["status"] =
        paidAmount >= invoice.netAmount
          ? "paid"
          : paidAmount > 0
            ? "partial"
            : "pending";
      const updated = invoices.map((item) =>
        item.id === invoiceId ? { ...item, payments, paidAmount, status } : item
      );
      await AsyncStorage.setItem("invoices", JSON.stringify(updated));
      setInvoices(updated);
    },
    [invoices, reports]
  );

  const updateReportSettings = useCallback(async (settings: ReportSettings) => {
    const normalized = {
      ...settings,
      customCycleDays: Math.max(1, Math.min(365, Math.round(settings.customCycleDays) || 30)),
    };
    await AsyncStorage.setItem("reportSettings", JSON.stringify(normalized));
    setReportSettings(normalized);
  }, []);

  const closeReports = useCallback(async (newReports: PeriodicReport[]) => {
    const alreadyClosed = new Set(reports.flatMap((report) => report.invoiceIds));
    const batchIds = new Set<string>();
    const duplicateIds: string[] = [];
    for (const report of newReports) {
      for (const invoiceId of report.invoiceIds) {
        if (alreadyClosed.has(invoiceId) || batchIds.has(invoiceId)) {
          duplicateIds.push(invoiceId);
        }
        batchIds.add(invoiceId);
      }
    }
    if (duplicateIds.length) {
      throw new Error("تحتوي الفترة على فواتير أُغلقت سابقًا. أعد تحديث المعاينة قبل الإغلاق.");
    }
    const invoiceMap = new Map(invoices.map((invoice) => [invoice.id, invoice]));
    for (const report of newReports) {
      for (const invoiceId of report.invoiceIds) {
        const invoice = invoiceMap.get(invoiceId);
        if (!invoice || invoice.status === "cancelled") {
          throw new Error("توجد فاتورة محذوفة أو ملغاة في التقرير. حدّث المعاينة وحاول مجددًا.");
        }
        if (
          invoice.insuranceCompanyId !== report.companyId ||
          (report.departmentId !== null && invoice.serviceDepartmentId !== report.departmentId) ||
          (invoice.currency ?? "SAR") !== report.currency
        ) {
          throw new Error("بيانات التقرير لا تطابق إحدى فواتيره؛ لم يتم إغلاق أي تقرير.");
        }
      }
    }
    const updated = [...reports, ...newReports];
    await AsyncStorage.setItem("periodicReports", JSON.stringify(updated));
    setReports(updated);
  }, [invoices, reports]);

  const addReportSettlement = useCallback(async (
    reportId: string,
    invoiceAllocations: ReportAllocation[],
    notes: string
  ) => {
    const report = reports.find((item) => item.id === reportId);
    if (!report) throw new Error("التقرير غير موجود.");
    if (!invoiceAllocations.length) {
      throw new Error("أدخل مبلغًا لفاتورة واحدة على الأقل.");
    }
    const allocationIds = new Set(invoiceAllocations.map((allocation) => allocation.invoiceId));
    if (allocationIds.size !== invoiceAllocations.length) {
      throw new Error("توجد فاتورة مكررة في توزيع الدفعة.");
    }
    const allocations = invoiceAllocations.map((allocation) => {
      if (!Number.isFinite(allocation.amount) || allocation.amount <= 0) {
        throw new Error("أدخل مبلغًا صحيحًا لكل فاتورة مدفوعة.");
      }
      if (!report.invoiceIds.includes(allocation.invoiceId)) {
        throw new Error("لا يمكن توزيع الدفعة على فاتورة خارج هذا التقرير.");
      }
      const invoice = invoices.find((item) => item.id === allocation.invoiceId);
      if (!invoice) throw new Error("تعذر العثور على فاتورة في هذا التقرير.");
      const alreadyAllocated = report.settlements.reduce(
        (sum, settlement) =>
          sum + settlement.allocations
            .filter((item) => item.invoiceId === invoice.id)
            .reduce((part, item) => part + item.amount, 0),
        0
      );
      const rejected = report.rejections
        .filter((rejection) => rejection.invoiceId === invoice.id)
        .reduce((sum, rejection) => sum + rejection.amount, 0);
      const available = Math.max(
        0,
        invoice.netAmount - invoice.paidAmount - alreadyAllocated - rejected
      );
      if (allocation.amount > available + 0.005) {
        throw new Error(
          `مبلغ الدفعة للفاتورة ${invoice.invoiceNumber} أكبر من المتبقي (${available}).`
        );
      }
      return { invoiceId: invoice.id, amount: allocation.amount };
    });
    const amount = allocations.reduce((sum, allocation) => sum + allocation.amount, 0);
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("أدخل مبلغ دفعة صحيح.");
    const settlement: ReportSettlement = {
      id: generateId(),
      amount,
      date: new Date().toISOString().slice(0, 10),
      notes: notes.trim(),
      allocations,
    };
    const updated = reports.map((item) =>
      item.id === reportId
        ? { ...item, settlements: [...item.settlements, settlement] }
        : item
    );
    await AsyncStorage.setItem("periodicReports", JSON.stringify(updated));
    setReports(updated);
  }, [invoices, reports]);

  const rejectReportInvoice = useCallback(async (
    reportId: string,
    invoiceId: string,
    reason: string
  ) => {
    const report = reports.find((item) => item.id === reportId);
    const invoice = invoices.find((item) => item.id === invoiceId);
    if (!report || !invoice || !report.invoiceIds.includes(invoiceId)) {
      throw new Error("تعذر العثور على الفاتورة المرتبطة بهذا التقرير.");
    }
    if (!reason.trim()) throw new Error("سبب الرفض مطلوب لحفظه في الأرشيف.");
    const paidThroughReport = report.settlements.reduce(
      (sum, settlement) =>
        sum + settlement.allocations
          .filter((allocation) => allocation.invoiceId === invoiceId)
          .reduce((part, allocation) => part + allocation.amount, 0),
      0
    );
    const previouslyRejected = report.rejections
      .filter((rejection) => rejection.invoiceId === invoiceId)
      .reduce((sum, rejection) => sum + rejection.amount, 0);
    const remaining = Math.max(
      0,
      invoice.netAmount - invoice.paidAmount - paidThroughReport - previouslyRejected
    );
    if (remaining <= 0.005) {
      throw new Error("لا يوجد مبلغ متبقٍ على هذه الفاتورة لرفضه.");
    }
    const rejection: ReportRejection = {
      id: generateId(),
      invoiceId,
      amount: remaining,
      reason: reason.trim(),
      date: new Date().toISOString().slice(0, 10),
    };
    const updated = reports.map((item) =>
      item.id === reportId
        ? { ...item, rejections: [...item.rejections, rejection] }
        : item
    );
    await AsyncStorage.setItem("periodicReports", JSON.stringify(updated));
    setReports(updated);
  }, [invoices, reports]);

  const getInvoicePaidAmount = useCallback((invoiceId: string) => {
    const direct = invoices.find((invoice) => invoice.id === invoiceId)?.paidAmount ?? 0;
    const allocated = reports.reduce(
      (sum, report) =>
        sum + report.settlements.reduce(
          (settlementSum, settlement) =>
            settlementSum + settlement.allocations
              .filter((allocation) => allocation.invoiceId === invoiceId)
              .reduce((part, allocation) => part + allocation.amount, 0),
          0
        ),
      0
    );
    return direct + allocated;
  }, [invoices, reports]);

  const getInvoiceRejectedAmount = useCallback((invoiceId: string) =>
    reports.reduce(
      (sum, report) =>
        sum + report.rejections
          .filter((rejection) => rejection.invoiceId === invoiceId)
          .reduce((part, rejection) => part + rejection.amount, 0),
      0
    ), [reports]);

  const isInvoiceInClosedReport = useCallback(
    (invoiceId: string) => reports.some((report) => report.invoiceIds.includes(invoiceId)),
    [reports]
  );

  return (
    <AppContext.Provider
      value={{
        entity,
        updateEntity,
        storageError,
        reloadData: loadData,
        insuranceCompanies,
        addInsuranceCompany,
        updateInsuranceCompany,
        deleteInsuranceCompany,
        employers,
        addEmployer,
        updateEmployer,
        deleteEmployer,
        subscribers,
        addSubscriber,
        updateSubscriber,
        deleteSubscriber,
        invoices,
        addInvoice,
        updateInvoice,
        cancelInvoice,
        addPayment,
        reports,
        reportSettings,
        updateReportSettings,
        closeReports,
        addReportSettlement,
        rejectReportInvoice,
        getInvoicePaidAmount,
        getInvoiceRejectedAmount,
        isInvoiceInClosedReport,
        loading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export { generateId };
