import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SQLite from "expo-sqlite";
import { isCurrencyCode } from "@/constants/currencies";
import type { Department, MainEntity } from "@/types/facility";

const DATABASE_NAME = "health-insurance.db";

interface FacilityRow {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  base_currency: string | null;
}

interface DepartmentRow {
  id: string;
  name: string;
  phone: string;
  active: number;
}

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

async function getDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!databasePromise) {
    databasePromise = (async () => {
      const database = await SQLite.openDatabaseAsync(DATABASE_NAME);
      await database.execAsync(`
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS facility_settings (
          id TEXT PRIMARY KEY NOT NULL,
          name TEXT NOT NULL DEFAULT '',
          address TEXT NOT NULL DEFAULT '',
          phone TEXT NOT NULL DEFAULT '',
          email TEXT NOT NULL DEFAULT '',
          website TEXT NOT NULL DEFAULT '',
          base_currency TEXT
            CHECK (base_currency IS NULL OR base_currency IN ('YER', 'SAR', 'USD')),
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS service_departments (
          id TEXT PRIMARY KEY NOT NULL,
          facility_id TEXT NOT NULL
            REFERENCES facility_settings(id) ON DELETE CASCADE,
          name TEXT NOT NULL CHECK (length(trim(name)) > 0),
          phone TEXT NOT NULL DEFAULT '',
          active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
          sort_order INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL,
          UNIQUE (facility_id, name COLLATE NOCASE)
        );
      `);
      return database;
    })().catch((error: unknown) => {
      databasePromise = null;
      throw error;
    });
  }

  return databasePromise;
}

function readLegacyEntity(raw: string | null, fallback: MainEntity): MainEntity {
  if (!raw) return fallback;

  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error("تعذرت قراءة بيانات المنشأة المحفوظة.");
  }

  if (!value || typeof value !== "object") {
    throw new Error("تنسيق بيانات المنشأة المحفوظة غير صالح.");
  }

  const legacy = value as Record<string, unknown>;
  const legacyDepartments = Array.isArray(legacy["departments"])
    ? legacy["departments"]
    : [];

  return {
    id: typeof legacy["id"] === "string" ? legacy["id"] : fallback.id,
    name: typeof legacy["name"] === "string" ? legacy["name"] : "",
    address: typeof legacy["address"] === "string" ? legacy["address"] : "",
    phone: typeof legacy["phone"] === "string" ? legacy["phone"] : "",
    email: typeof legacy["email"] === "string" ? legacy["email"] : "",
    website: typeof legacy["website"] === "string" ? legacy["website"] : "",
    baseCurrency: isCurrencyCode(legacy["baseCurrency"])
      ? legacy["baseCurrency"]
      : null,
    departments: legacyDepartments
      .filter(
        (department): department is Record<string, unknown> =>
          !!department &&
          typeof department === "object" &&
          typeof (department as Record<string, unknown>)["id"] === "string" &&
          typeof (department as Record<string, unknown>)["name"] === "string"
      )
      .map((department) => ({
        id: department["id"] as string,
        name: (department["name"] as string).trim(),
        phone:
          typeof department["phone"] === "string" ? department["phone"] : "",
        active: department["active"] !== false,
      }))
      .filter((department) => department.name.length > 0),
  };
}

async function writeFacility(
  database: SQLite.SQLiteDatabase,
  entity: MainEntity
): Promise<void> {
  if (!entity.id.trim()) throw new Error("معرّف المنشأة غير صالح.");
  if (entity.baseCurrency !== null && !isCurrencyCode(entity.baseCurrency)) {
    throw new Error("العملة الأساسية المختارة غير مدعومة.");
  }

  const now = new Date().toISOString();
  await database.withTransactionAsync(async () => {
    await database.runAsync(
      `INSERT INTO facility_settings
        (id, name, address, phone, email, website, base_currency, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         name = excluded.name,
         address = excluded.address,
         phone = excluded.phone,
         email = excluded.email,
         website = excluded.website,
         base_currency = excluded.base_currency,
         updated_at = excluded.updated_at`,
      [
        entity.id,
        entity.name.trim(),
        entity.address.trim(),
        entity.phone.trim(),
        entity.email.trim(),
        entity.website.trim(),
        entity.baseCurrency,
        now,
      ]
    );

    await database.runAsync(
      "UPDATE service_departments SET active = 0, updated_at = ? WHERE facility_id = ?",
      [now, entity.id]
    );

    for (const [index, department] of entity.departments.entries()) {
      const name = department.name.trim();
      if (!department.id.trim() || !name) {
        throw new Error("يجب إدخال اسم صحيح لكل قسم.");
      }

      await database.runAsync(
        `INSERT INTO service_departments
          (id, facility_id, name, phone, active, sort_order, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           facility_id = excluded.facility_id,
           name = excluded.name,
           phone = excluded.phone,
           active = excluded.active,
           sort_order = excluded.sort_order,
           updated_at = excluded.updated_at`,
        [
          department.id,
          entity.id,
          name,
          department.phone.trim(),
          department.active === false ? 0 : 1,
          index,
          now,
        ]
      );
    }
  });
}

export async function loadFacilitySettings(
  fallback: MainEntity
): Promise<MainEntity> {
  const database = await getDatabase();
  let facility = await database.getFirstAsync<FacilityRow>(
    "SELECT id, name, address, phone, email, website, base_currency FROM facility_settings LIMIT 1"
  );

  if (!facility) {
    const legacyValue = await AsyncStorage.getItem("entity");
    const initialEntity = readLegacyEntity(legacyValue, fallback);
    await writeFacility(database, initialEntity);
    facility = await database.getFirstAsync<FacilityRow>(
      "SELECT id, name, address, phone, email, website, base_currency FROM facility_settings LIMIT 1"
    );
  }

  if (!facility) throw new Error("لم يتم إنشاء سجل المنشأة في قاعدة البيانات.");

  const rows = await database.getAllAsync<DepartmentRow>(
    `SELECT id, name, phone, active
     FROM service_departments
     WHERE facility_id = ?
     ORDER BY sort_order ASC, name COLLATE NOCASE ASC`,
    [facility.id]
  );

  return {
    id: facility.id,
    name: facility.name,
    address: facility.address,
    phone: facility.phone,
    email: facility.email,
    website: facility.website,
    baseCurrency: isCurrencyCode(facility.base_currency)
      ? facility.base_currency
      : null,
    departments: rows.map((row) => ({
      id: row.id,
      name: row.name,
      phone: row.phone,
      active: row.active === 1,
    })),
  };
}

export async function saveFacilitySettings(
  entity: MainEntity
): Promise<void> {
  const database = await getDatabase();
  await writeFacility(database, entity);
}
