import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

type BadgeVariant = "success" | "warning" | "error" | "info" | "muted";

interface BadgeProps {
  label: string;
  variant?: BadgeVariant;
}

export function Badge({ label, variant = "info" }: BadgeProps) {
  const colors = useColors();

  const bg =
    variant === "success"
      ? colors.success + "20"
      : variant === "warning"
        ? colors.warning + "20"
        : variant === "error"
          ? colors.destructive + "20"
          : variant === "muted"
            ? colors.muted
            : colors.primary + "20";

  const text =
    variant === "success"
      ? colors.success
      : variant === "warning"
        ? colors.warning
        : variant === "error"
          ? colors.destructive
          : variant === "muted"
            ? colors.mutedForeground
            : colors.primary;

  return (
    <View style={[styles.badge, { backgroundColor: bg }]}>
      <Text style={[styles.label, { color: text }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 100,
    alignSelf: "flex-start",
  },
  label: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
});
