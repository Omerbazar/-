---
name: Insurance app decisions
description: User-confirmed scope and calculation rules for the health-insurance app.
---

The first version is intended for one Android device, one operator, and offline use. Multi-user role administration and cross-device synchronization are not part of this confirmed v1 scope.

Supported currencies for the initial version are Yemeni rial (YER), Saudi riyal (SAR), and US dollar (USD). The user chooses one base currency. Exchange rates are entered manually per invoice, and payments may use a currency different from the invoice, with a separate rate recorded at payment time.

The user's stated calculation is based on the service amount: coinsurance is 25%, the contract discount is 10%, and the insurer pays the remainder (65%). For a 10,000 invoice, that means 2,500 coinsurance, 1,000 discount, and 6,500 due from the insurer. The discount is not a payment.

**Why:** These operating and financial rules were stated by the user and must not be replaced by assumptions.

**How to apply:** Settle foreign-currency payments in the selected base currency using the independently recorded payment-time rate, and store any exchange difference. Do not value a payment using the invoice-time rate.

Periodic reports are only closed after the user reviews and confirms the date range and invoice list. Sharing or exporting a report must not close the period. A closed report permanently records its invoice set so those invoices cannot be included in another periodic report. Record company payments against explicit per-invoice amounts; do not guess a FIFO allocation when an insurer pays only part of a report or rejects invoices.

**Why:** The user emphasized that omitted or duplicated invoices and incorrect payment allocation can cause serious financial errors.

**How to apply:** Keep report closure explicit and auditable. Validate invoice membership and remaining balances before saving payments or rejections, and preserve the original closed report when an invoice is disputed.
